<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About extends Model
{
   protected $table = "abouts";
   public $primaryKey = "id";
   public $timeStamps = true;
   protected $fillable=['title','body','pic','signature'];
}
