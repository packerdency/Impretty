<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\About;

class AboutUsController extends Controller
{
    Public function index() {
        $about = about::latest()->first();
          return view('frontend.aboutUs')
          ->with('about',$about);
       }
}
