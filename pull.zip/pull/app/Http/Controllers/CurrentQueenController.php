<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\pqueen;
use DB;

class CurrentQueenController extends Controller
{
    Public function index() {
        $pqueen = Pqueen::latest()->first();
  
           return view('frontend.currentQueen')
           ->with('pqueen', $pqueen);
  
      }
}
