<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Blog;
use DB;

class EventsController extends Controller
{
    Public function index() {
        $blog = Blog::latest()->get();
  
           return view('events.events')
           ->with('blogs', $blog);
  
      }
      public function show($id){
        $blog = Blog::find($id);
        return view('events.show')->with('blog', $blog);
      }

}
