<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\About;
use App\Gallery;
use App\Blog;
use App\Sponsors;
use App\Socialmedia;
use App\Partner;
use App\Pqueen;
use App\Project;
use App\Pwinner;
use DB;

class FrontendController extends Controller
{
   
  
  Public function index() {
      $pqueen = Pqueen::latest()->get();

      $pwinner = Pwinner::latest()->get();

      $project = Project::latest()->get();

      $socialmedia = Socialmedia::latest()->get();

      $sponsor = Sponsors::latest()->get();
      
      $blog = Blog::latest()->get();

      $gallery = Gallery::latest()->get();
    
       $about = about::latest()->first();

         return view('index')
         ->with('pqueen', $pqueen)
         ->with('pwinner', $pwinner)
         ->with('project', $project)
         ->with('socialmedia', $socialmedia)
         ->with('sponsors', $sponsor)
         ->with('blogs', $blog)
         ->with('galleries', $gallery)
         ->with('about',$about);

    }
    public function aboutUs(){
        return view('frontend.aboutUs');
    }

    public function events(){
        return view('events');
    }
 
    public function galleries(){
        return view('frontend.galleries');
    }


    public function howtoenter(){
        return view('frontend.howtoenter');
    }

    public function partners(){
        return view('frontend.partners');
    }

    public function brand(){
        return view('frontend.brand');
    }

    public function histories(){
        return view('frontend.histories');
    }

    public function projects(){
        return view('frontend.projects');
    }

    public function pqueen(){
        return view('frontend.currentQueen');
    }

    public function pwinners(){
        return view('frontend.pwinners');
    }

    public function sponsorrequest(){
        return view('frontend.requests');
    }
}