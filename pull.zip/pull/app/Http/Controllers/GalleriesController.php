<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Gallery;

class GalleriesController extends Controller
{
    Public function index() {  
        $gallery = Gallery::latest()->get();
  
           return view('frontend.galleries')
           ->with('galleries', $gallery);
        }
           
}
