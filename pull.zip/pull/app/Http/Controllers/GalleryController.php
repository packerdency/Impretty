<?php

namespace App\Http\Controllers;

use\App\Gallery;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class GalleryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $galleries = gallery:: latest()->paginate(3);
        return view('gallery.index', compact('galleries'))
        ->with('i',(request()->input('page',1)-1)*5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('gallery.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'fname' => 'required',
            'lname' => 'required',
            'location' => 'required',
            'w' => 'required',
            'height' => 'required',
            'age' => 'required',
            'hair' => 'required',
            'year' => 'required',
            'pic' => 'image|nullable|max:2000'
        ]);
        if($request->hasFile('pic')){
            $filenameWithExt = $request->file('pic')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('pic')->getClientOriginalExtension();
            $fileNameToStore=$filename.'_'.time().'.'.$extension;
            $path = $request->file('pic')->storeAs('public/upload', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';
        }

        $galleries = new Gallery;
        $galleries->fname=$request->input('fname');
        $galleries->lname=$request->input('lname');
        $galleries->w=$request->input('w');
        $galleries->height=$request->input('height');
        $galleries->age=$request->input('age');
        $galleries->hair=$request->input('hair');
        $galleries->location=$request->input('location');
        $galleries->year=$request->input('year');
        $galleries->pic=$fileNameToStore;
        $galleries->save();
        return redirect('/gallery')
        ->with('success','Your Page Info has been successfully Posted');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $galleries = Gallery::find($id);
        return view('gallery.show')->with('gallery', $galleries);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $galleries = Gallery::find($id);
        return view('gallery.edit')->with('gallery', $galleries);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'fname'=>'required',
            'lname'=>'required',
            'location'=>'required',
            'w'=>'required',
            'height'=>'required',
            'age'=>'required',
            'hair'=>'required',
            'year'=>'required'
        ]);
        $galleries=Gallery::find($id);
        if($request->hasFile('pic')){
            $filenameWithExt = $request->file('pic')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('pic')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('pic')->storeAs('public/upload', $fileNameToStore);
            Storage::delete('public/upload/'.$galleries->pic);
        }
        $galleries->fname =$request->get('fname');
        $galleries->lname =$request->get('lname');
        $galleries->w =$request->get('w');
        $galleries->height =$request->get('height');
        $galleries->age =$request->get('age');
        $galleries->hair =$request->get('hair');
        $galleries->location =$request->get('location');
        $galleries->year =$request->get('year');
        if($request->hasFile('pic')){
            $galleries->pic = $fileNameToStore;
        }
        $galleries->save();
        return redirect()->route('gallery.index')
        ->with('success','Beauty Queen details updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $galleries=Gallery::find($id);
        $galleries->delete();
        return redirect()->route('gallery.index')
        ->with('success','Gallery Item deleted successfully');
    }
}
