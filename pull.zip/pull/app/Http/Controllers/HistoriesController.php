<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\history;
use DB;

class HistoriesController extends Controller
{
    Public function index() {
        $history = History::latest()->first();
  
           return view('frontend.histories')
           ->with('history', $history);
  
      }
}
