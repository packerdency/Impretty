<?php

namespace App\Http\Controllers;

use\App\History;
use Illuminate\Http\Request;

class HistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $history = History::orderBy('created_at','desc')->paginate(5);
        return view('history.index')->with('history', $history);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('history.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'title' => 'required',
            'body' => 'required'
        ]);

       $history = new History;
       $history->title=$request->input('title');
       $history->body=$request->input('body');
       $history->save();
        return redirect() ->route('history.index')
        ->with('success','You have created history page successfully ');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $history = History::find($id);
        return view('history.show')->with('history', $history);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $history = History::find($id);
        return view('history.edit')->with('history', $history);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required',
            'body' => 'required'
        ]);
        $history=History::find($id);
        $history->title =$request->get('title');
        $history->body =$request->get('body');
        $history->save();
        return redirect()->route('history.index')
        ->with('success','You have successfully updated history page ');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $history=History::find($id);
        $history->delete();
        return redirect()->route('history.index')
        ->with('success','History Page deleted successfully');
    }
}
