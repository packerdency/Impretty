<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboard');
    }
    public function create(){
        return view('users.create');
    }
    public function update(Request $request){
        $this->validate($request,[
            'old'=> 'required',
            'password' => 'required|min:10|confirmed',
        ]);

        $user = User::find(Auth::id());
        $hashedPassword = $user->password;
        if(Hash::check($request->old, $hashedPassword)){
            $user->fill([
                'password' => Hash::make($request->password)
            ])->save();
            $request->session()->flash('success', 'Your password has been changed successfully.');
            return back();
        }
        $request->session()->flash('failure', 'Your password has not been changed.');
        return back();
    }
}
