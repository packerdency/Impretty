<?php

namespace App\Http\Controllers;

use App\models;
use Illuminate\Http\Request;

class ModelsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $models = Models::orderBy('created_at','desc')->paginate(5);
        return view('model.index')->with('models', $models);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('model.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'fname' => 'required',
            'lname' => 'required',
           // 'image' => 'required'
        ]);
        $models = new Models;
        $models->fname=$request->input('fname');
        $models->lname=$request->input('lname');
        //$blogs->image=$request->input('image');
        $models->save();
        return redirect('/model')->with ('success','Your Blog Post has been successfully Posted');
       // $request -> validate([
           // 'fname' => 'required',
            //'lname' => 'required',
            //'age' => 'required',
            //'weight' => 'required',
            //'height' => 'required',
            //'year' => 'required',
           // 'hair' => 'required',
           // 'pic' => 'required'
       // ]);
        //$models = new Models;
        //$models->fname=$request->input('fname');
       // $models->lname=$request->input('lname');
        //$models->age=$request->input('age');
       // $models->weight=$request->input('weight');
       // $models->height=$request->input('height');
        //$models->year=$request->input('year');
        //$models->hair=$request->input('hair');
        //$models->pic=$request->input('pic');
       // $models->save();
       // return redirect('/model')->with ('success','You successfully uploaded new model');        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\models  $models
     * @return \Illuminate\Http\Response
     */
    public function show(models $models)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\models  $models
     * @return \Illuminate\Http\Response
     */
    public function edit(models $models)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\models  $models
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, models $models)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\models  $models
     * @return \Illuminate\Http\Response
     */
    public function destroy(models $models)
    {
        //
    }
}
