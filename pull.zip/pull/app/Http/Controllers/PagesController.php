<?php

namespace App\Http\Controllers;

use App\About;
use App\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class PagesController extends Controller
{
    /*
    public function index(){
        return view('pages.index');
    }

    public function aboutUs(){
        return view('pages.aboutUs');
    }

    public function events(){
        return view('pages.events');
    }

    public function galleries(){
        return view('pages.galleries');
    }

    public function howtoenter(){
        return view('pages.howtoenter');
    }

    public function partners(){
        return view('pages.partners');
    }

    public function brand(){
        return view('pages.brand');
    }

    public function histories(){
        return view('pages.histories');
    }

    public function projects(){
        return view('pages.projects');
    }

    public function pqueen(){
        return view('pages.pqueen');
    }

    public function pwinners(){
        return view('pages.pwinners');
    }

    public function sponsorrequest(){
        return view('pages.requests');
    }
    */
}
