<?php

namespace App\Http\Controllers;

use App\Sponsors;
use Illuminate\Http\Request;
use DB;

class PartnerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
     {
        $sponsor = Sponsors::latest()->get();
  
           return view('frontend.partners')
           ->with('sponsors', $sponsor);
  
      }
}