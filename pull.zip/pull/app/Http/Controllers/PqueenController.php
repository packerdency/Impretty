<?php

namespace App\Http\Controllers;

use App\Pqueen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB;

class PqueenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pqueen = Pqueen::orderBy('created_at','desc')->paginate(5);
        return view('pqueen.index')->with('pqueen', $pqueen);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pqueen.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'name' => 'required',
            'body' => 'required',
            'facebook' => 'required',
            'twitter' => 'required',
            'instagram' =>'required',
            'picture' => 'image|nullable|max:2000'
        ]);

            if($request->hasFile('picture')){
                $filenameWithExt = $request->file('picture')->getClientOriginalName();
                $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
                $extension = $request->file('picture')->getClientOriginalExtension();
                $fileNameToStore=$filename.'_'.time().'.'.$extension;
                $path = $request->file('picture')->storeAs('public/upload', $fileNameToStore);
            }else{
                $fileNameToStore = 'noimage.jpg';
            }

        $pqueen = new Pqueen;
        $pqueen->name=$request->input('name');
        $pqueen->body=$request->input('body');
        $pqueen->facebook=$request->input('facebook');
        $pqueen->twitter=$request->input('twitter');
        $pqueen->instagram=$request->input('instagram');
        $pqueen->picture=$fileNameToStore;
        $pqueen->save();
        return redirect('/pqueen')->with ('success','Your Post has been successfully Posted');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\pqueen  $pqueen
     * @return \Illuminate\Http\Response
     */
    public function show(pqueen $pqueen)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\pqueen  $pqueen
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pqueen = Pqueen::find($id);
        return view('pqueen.edit')->with('pqueen', $pqueen);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\pqueen  $pqueen
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,  $id)
    {
        $request->validate([
            'name' => 'required',
            'body' => 'required',
            'facebook' => 'required',
            'twitter' => 'required',
            'instagram' => 'required'
        ]);
    
        $pqueen=Pqueen::find($id);
        if($request->hasFile('picture')){
            $filenameWithExt = $request->file('picture')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('picture')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('picture')->storeAs('public/upload', $fileNameToStore);
            Storage::delete('public/upload/'.$pqueen->picture);
        }
        $pqueen->name =$request->get('name');
        $pqueen->body =$request->get('body');
        $pqueen->facebook =$request->get('facebook');
        $pqueen->twitter =$request->get('twitter');
        $pqueen->instagram =$request->get('instagram');
        if($request->hasFile('picture')){
            $pqueen->picture = $fileNameToStore;
        }
        $pqueen->save();
        return redirect()->route('pqueen.index')
        ->with('success','You have successfully updated your data ');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\pqueen  $pqueen
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pqueen=Pqueen::find($id);

        if($pqueen->picture !='noimage.jpg'){
            Storage::delete('public/upload'.$pqueen->picture);
        }

        $pqueen->delete();
        return redirect()->route('pqueen.index')
        ->with('success','Item deleted successfully');
    }
}
