<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;

class ProjectsController extends Controller
{
    Public function index() {
        $project = Project::latest()->get();
  
           return view('human.projects')
           ->with('project', $project);
  
      }
      public function show($id){
        $project = Project::find($id);
        return view('human.show')->with('project', $project);
      }
}
