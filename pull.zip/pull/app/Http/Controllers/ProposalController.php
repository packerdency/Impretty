<?php

namespace App\Http\Controllers;

use App\Proposal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class ProposalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $proposal = Proposal::orderBy('created_at','desc')->paginate(5);
        return view('proposal.index')->with('proposal', $proposal);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('proposal.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'company' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'city' => 'required',
            'country' => 'required',
            'message' => 'required'
        ]);

       $proposal = new Proposal;
       $proposal->company=$request->input('company');
       $proposal->phone=$request->input('phone');
       $proposal->email=$request->input('email');
       $proposal->city=$request->input('city');
       $proposal->country=$request->input('country');
       $proposal->message=$request->input('message');
       $proposal->save();
        return redirect() ->route('proposal.create')
        ->with('success','Your Application  has been successfully submitted');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\proposal  $proposal
     * @return \Illuminate\Http\Response
     */
    public function show(proposal $proposal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\proposal  $proposal
     * @return \Illuminate\Http\Response
     */
    public function edit(proposal $proposal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\proposal  $proposal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, proposal $proposal)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\proposal  $proposal
     * @return \Illuminate\Http\Response
     */
    public function destroy(proposal $proposal)
    {
        //
    }
}
