<?php

namespace App\Http\Controllers;

use App\Pwinner;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class PwinnerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $pwinner = Pwinner::orderBy('created_at','desc')->paginate(5);
        return view('pwinner.index')->with('pwinner', $pwinner);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('pwinner.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'name' => 'required',
            'year' => 'required'
        ]);

        $pwinner = new Pwinner;
        $pwinner->name=$request->input('name');
        $pwinner->year=$request->input('year');
        $pwinner->save();
        return redirect('/pwinner')->with ('success','You have have successfully Added a new record');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\pwinner  $pwinner
     * @return \Illuminate\Http\Response
     */
    public function show(pwinner $pwinner)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\pwinner  $pwinner
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $pwinner = Pwinner::find($id);
        return view('pwinner.edit')->with('pwinner', $pwinner);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\pwinner  $pwinner
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
            'year' => 'required'
        ]);
        $pwinner=Pwinner::find($id);
        $pwinner->name =$request->get('name');
        $pwinner->year =$request->get('year');
        $pwinner->save();
        return redirect()->route('pwinner.index')
        ->with('success','You have successfully updated your data ');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\pwinner  $pwinner
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $pwinner=Pwinner::find($id);
        $pwinner->delete();
        return redirect()->route('pwinner.index')
        ->with('success','Operation successful');
    }
}
