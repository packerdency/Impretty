<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Pwinner;

class PwinnersController extends Controller
{
    Public function index() {
        $pwinner = pwinner::latest()->get();
          return view('frontend.pwinners')
          ->with('pwinner',$pwinner);
       }
}
