<?php

namespace App\Http\Controllers;

use App\Registration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use DB; 

class RegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $registrations = Registration::orderBy('created_at','desc')->paginate(5);
        return view('registration.index')->with('registrations', $registrations);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('registration.create');
    }

   /* public function prnpriview($id)
    {
        $registrations = Registration::all($id);
        return view('registration.create')->('registrations',$registrations);
    }
    */

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'name' => 'required',
            'phone' => 'required',
            'age' => '',
            'dob' => 'required',
            'occupation' => '',
            'location' => 'required',
            'email' => 'required|email|nullable|distinct',
            'hobbies' => '',
            'parentNumber' => 'required',
            'highschool' => 'required',
            'localLanguage' => '',
            'address' => 'required',
            'gain' => 'required',
            'goal' => 'required',
            'previousPageant' => '',
            'pageant' => '',
            'aboutMe' => '',
            'height' => 'required',
            'weight' => 'required',
            'hair' => 'required',
            'passport' => 'image|nullable|max:7000',
            'idcard' => 'image|nullable|max:2000',
            'birthCert' => 'image|nullable|max:2000'
        ]);
        if($request->hasFile('passport')){
            $filenameWithExt = $request->file('passport')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('passport')->getClientOriginalExtension();
            $fileNameToStore=$filename.'_'.time().'.'.$extension;
            $path = $request->file('passport')->storeAs('public/upload', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';
        }
        if($request->hasFile('idcard')){
            $filenameWithExt = $request->file('idcard')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('idcard')->getClientOriginalExtension();
            $fileNameToStore=$filename.'_'.time().'.'.$extension;
            $path = $request->file('idcard')->storeAs('public/upload', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';
        }
        if($request->hasFile('birthCert')){
            $filenameWithExt = $request->file('birthCert')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('birthCert')->getClientOriginalExtension();
            $fileNameToStore=$filename.'_'.time().'.'.$extension;
            $path = $request->file('birthCert')->storeAs('public/upload', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';
        }

       // Registration::create($request->all());
       $registrations = new Registration;
       $registrations->name=$request->input('name');
       $registrations->phone=$request->input('phone');
       $registrations->age=$request->input('age');
       $registrations->dob=$request->input('dob');
       $registrations->occupation=$request->input('occupation');
       $registrations->location=$request->input('location');
       $registrations->email=$request->input('email');
       $registrations->hobbies=$request->input('hobbies');
       $registrations->parentNumber=$request->input('parentNumber');
       $registrations->highschool=$request->input('highschool');
       $registrations->localLanguage=$request->input('localLanguage');
       $registrations->address=$request->input('address');
       $registrations->gain=$request->input('gain');
       $registrations->goal=$request->input('goal');
       $registrations->aboutMe=$request->input('aboutMe');
       $registrations->height=$request->input('height');
       $registrations->weight=$request->input('weight');
       $registrations->hair=$request->input('hair');
       $registrations->passport=$fileNameToStore;
       $registrations->idcard=$fileNameToStore;
       $registrations->birthCert=$fileNameToStore;
       $registrations->save();
        return redirect() ->route('registration.create')
        ->with('success','Your Application for this edition of IMPRETTY has been successfully submitted');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $registrations = Registration::find($id);
        return view('registration.show')->with('registration', $registrations);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $registrations=Registration::find($id);
        $registrations->delete();
        return redirect()->route('registration.index')
        ->with('success','Entry deleted successfully');
    }
}
