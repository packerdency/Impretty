<?php

namespace App\Http\Controllers;

use App\socialmedia;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class SocialmediaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $socialmedia = Socialmedia::orderBy('created_at','desc')->paginate(5);
        return view('social.index')->with('socialmedia', $socialmedia);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('social.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'facebook' => 'required',
            'twitter' => 'required',
            'instagram' => 'required',
            'youtube' => 'required'
        ]);
        $socialmedia = new Socialmedia;
        $socialmedia->facebook=$request->input('facebook');
        $socialmedia->twitter=$request->input('twitter');
        $socialmedia->instagram=$request->input('instagram');
        $socialmedia->youtube=$request->input('youtube');
        $socialmedia->save();
        return redirect('/social')->with ('success','You have successfully entered social media handles');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\socialmedia  $socialmedia
     * @return \Illuminate\Http\Response
     */
    public function show(socialmedia $socialmedia)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\socialmedia  $socialmedia
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $socialmedia = Socialmedia::find($id);
        return view('social.edit')->with('socialmedia', $socialmedia);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\socialmedia  $socialmedia
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $request->validate([
            'facebook' => 'required',
            'twitter' => 'required',
            'instagram' => 'required',
            'youtube' => 'required'
        ]);
        $socialmedia=Socialmedia::find($id);
        $socialmedia->facebook =$request->get('facebook');
        $socialmedia->twitter =$request->get('twitter');
        $socialmedia->instagram =$request->get('instagram');
        $socialmedia->youtube =$request->get('youtube');
        $socialmedia->save();
        return redirect()->route('social.index')
        ->with('success','You have successfully updated social media handles ');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\socialmedia  $socialmedia
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $socialmedia=Socialmedia::find($id);
        $socialmedia->delete();
        return redirect()->route('social.index')
        ->with ('success','You have successfully deleted social media handles ');
    }
}
