<?php

namespace App\Http\Controllers;

use App\Sponsors;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use DB; 

class SponsorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sponsors = Sponsors::orderBy('created_at','desc')->paginate(5);
        return view('sponsor.index')->with('sponsors', $sponsors);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('sponsor.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request -> validate([
            'name' => 'required',
            'logo' => 'image|nullable|max:2000'
        ]);

        
        if($request->hasFile('logo')){
            $filenameWithExt = $request->file('logo')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('logo')->getClientOriginalExtension();
            $fileNameToStore=$filename.'_'.time().'.'.$extension;
            $path = $request->file('logo')->storeAs('public/upload', $fileNameToStore);
        }else{
            $fileNameToStore = 'noimage.jpg';
        }
        $sponsors = new Sponsors;
        $sponsors->name=$request->input('name');
        $sponsors->logo=$fileNameToStore;
        $sponsors->save();
        return redirect('/sponsor')->with ('success','You have have successfully Added a new sponsor/partner');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sponsors = Sponsors::find($id);
        return view('sponsor.edit')->with('sponsors', $sponsors);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required'
        ]);
        $sponsors=Sponsors::find($id);
        if($request->hasFile('image')){
            $filenameWithExt = $request->file('image')->getClientOriginalName();
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $filename.'_'.time().'.'.$extension;
            $path = $request->file('image')->storeAs('public/upload', $fileNameToStore);
            Storage::delete('public/upload/'.$sponsors->image);
        }
        $sponsors->name =$request->get('name');
        if($request->hasFile('image')){
            $sponsors->image = $fileNameToStore;
        }
        $sponsors->save();
        return redirect()->route('sponsor.index')
        ->with('success','You have successfully updated social Sponsor/Partner Info ');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sponsors=Sponsors::find($id);
        $sponsors->delete();
        return redirect()->route('sponsor.index')
        ->with('success','Sponsor/Partner deleted successfully');
    }
}
