<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class blog extends Model
{
    protected $table = "blogs";
    public $primaryKey = "id";
    public $timeStamps = true;

    protected $fillable=['title','description','image','m_tittle','m_desc'];
}
