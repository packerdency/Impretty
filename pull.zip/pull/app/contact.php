<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact extends Model
{
    protected $table = "contacts";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['fullname','email','phone','location','message'];
}
