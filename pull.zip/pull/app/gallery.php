<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gallery extends Model
{
    protected $table = "galleries";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['fname','lname','pic','location','height','age','location','hair','year'];
    
}
