<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class models extends Model
{
    protected $table = "models";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['fname','lname','pic','location','height','age','hair','year'];
}
