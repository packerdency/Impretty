<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class partner extends Model
{
    protected $table = "partners";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['name','image'];
}
