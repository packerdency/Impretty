<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pqueen extends Model
{
    protected $table = "pqueens";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['name','body','picture','facebook','twitter','instagram'];
}
