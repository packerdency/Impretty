<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class project extends Model
{
    protected $table = "projects";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['title','body','cover_image'];
}
