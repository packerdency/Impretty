<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class proposal extends Model
{
    protected $table = "proposals";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['company','phone','email','city','country','message'];
}
