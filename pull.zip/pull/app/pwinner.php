<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pwinner extends Model
{
    protected $table = "pwinners";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['name','year'];
}
