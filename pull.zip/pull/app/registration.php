<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registration extends Model
{
    protected $table = "registrations";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['name','phone','age','dob','occupation','location','email','hobbies',
    'parentNumber','highschool','university','localLanguage','address','gain','goal','auditionLocation','previousPageant',
    'pageant','aboutMe','height','weight','hair','passport','idcard','birthCert'];
}
