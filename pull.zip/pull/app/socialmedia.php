<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class socialmedia extends Model
{
    protected $table = "socialmedia";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['facebook','twitter','intagram','youtube'];
}
