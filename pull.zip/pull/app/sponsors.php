<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class sponsors extends Model
{
    protected $table = "sponsors";
    public $primaryKey = "id";
    public $timeStamps = true;
    protected $fillable=['name','image'];
}
