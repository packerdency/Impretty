<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistrationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registrations', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('phone');
            $table->string('age');
            $table->string('dob');
            $table->string('occupation')->nullable();
            $table->string('location');
            $table->string('email');
            $table->text('hobbies');
            $table->string('parent-number');
            $table->string('highschool');
            $table->string('university');
            $table->string('localLanguage');
            $table->text('address');
            $table->string('gain');
            $table->string('goal');
            $table->string('auditionLocation');
            $table->string('previousPageant');
            $table->string('pageant');
            $table->string('aboutMe');
            $table->string('height');
            $table->string('weight');
            $table->string('hair');
            $table->string('passport');
            $table->string('idcard');
            $table->string('birthCert');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registrations');
    }
}
