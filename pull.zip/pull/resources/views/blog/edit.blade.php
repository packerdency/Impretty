@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title"> Edit Blog Post</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{route('blog.update',$blog->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">
        <div class="form-group">
          <label for="title">Title</label>
        <input type="text" class="form-control" name="title" id="title" value="{{$blog->title}}">
        </div>
        <div class="form-group">
          <label for="description">Description</label>
          <textarea name="description" class="form-control" id="description" cols="30" rows="10">{{$blog->description}}</textarea>
        </div>
        <div class="form-group">
          <label for="image">Blog Image</label>
          <input type="file" id="image" name="image" value="{{$blog->image}}">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection