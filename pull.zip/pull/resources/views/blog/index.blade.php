@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Blog Posts
      <small>News </small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Blog</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

@if(count($blogs)>0)
<table id="example1" class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>ID </th>
            <th>Title</th>
            <th>Description</th>
            <th>Image </th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
            @foreach($blogs as $blog)
            <tr>
                <td>{{ $blog->id}}</td>
                <td>{{ $blog->title}}</td>
                <td>{{ $blog->description}}</td>
                <td><img src="{{url('/storage/upload')}}/{{($blog->image)}}" width="30%"/></td>
                <td>
                    <form action="{{route('blog.destroy',$blog->id)}}" method="post">
                        <a href="{{route('blog.edit',$blog->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                </td>
              </tr>
              @endforeach
        </tbody>
        <tfoot>
            <tr>
                <th>ID </th>
                <th>Title</th>
                <th>Description</th>
                <th>Image </th>
                <th>Actions</th>
            </tr>
            </tfoot>
</table>
{{ $blogs->links() }}
@else
<p>No Blog post found</p>
@endif
</section>
@endsection