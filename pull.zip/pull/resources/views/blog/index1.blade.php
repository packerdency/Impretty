@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Blog Posts
      <small>News </small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Blog</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
                <th>ID </th>
                <th>Title</th>
                <th>Description</th>
                <th>Image </th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($blogs as $blog)
                <tr>
                    <td>{{ $blog->id}}</td>
                    <td>{{ $blog->title}}</td>
                    <td>{{ $blog->description}}</td>
                    <td>{{ $blog->image }}</td>
                    <td>
                        <a href="#" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        <a href="#" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Image </th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
  </section>
@endsection