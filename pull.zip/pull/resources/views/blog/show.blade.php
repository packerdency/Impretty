@extends('layouts.master')
@section('content')
			<section class="ds s-pt-70 s-pb-50 s-pb-sm-70 s-py-lg-100 s-py-xl-150 c-gutter-60">
				<div class="container">
					<div class="row">
						<div class="offset-lg-1 col-lg-10">
							<article class="vertical-item post type-post status-publish format-standard has-post-thumbnail content-padding border-rad-5">

								<!-- .post-thumbnail -->
								<div class="item-media post-thumbnail">
									<img src="images/blog/01.jpg" alt="img">
								</div>


								<div class="item-content ds ">
									<header class="entry-header">
										<a href="blog-single-left.html" rel="bookmark">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">{{$blog->created_at}}</time>
										</a>
									</header>
									<!-- .entry-header -->

									<div class="entry-content">
										<h1 class="entry-title">
											<a href="blog-single-left.html" rel="bookmark">
												{{$blog->title}}
											</a>
										</h1>

										<p> {{$blog->description}} </p>

										<div class="item-media post-thumbnail">
											<div class="embed-responsive embed-responsive-3by2">
												<a href="https://www.youtube.com/embed/mcixldqDIEQ" class="embed-placeholder">
													<img src="images/post/03.jpg" alt="img">
												</a>
											</div>

										</div><!-- .post-thumbnail -->
										<div class="divider-55 hidden-below-lg"></div>
										<div class="divider-30 hidden-above-lg"></div>

								</div>
								<!-- .item-content -->
								<div class="item-meta flex-wrap d-flex ds">
									<a href="blog-single-left.html"><i class="fa fa-user color-main"></i>admin</a>
									<a href="blog-left.html"><i class="fa fa-tag color-main"></i>session</a>
									<a href="blog-single-left.html"><i class="fa fa-comment color-main"></i>5 comments</a>
								</div>

								<h3 class="title-post">Related Posts</h3>

								<!-- Widget_slider -->
								<div class="widget widget_slider">
									<div class="owl-carousel top-right-nav" data-nav="false" data-loop="true" data-autoplay="true" data-items="1" data-responsive-lg="2" data-responsive-md="2" data-responsive-sm="2" data-responsive-xs="1">
										<div class="vertical-item">
											<div class="item-media">
												<img class="rounded-0" src="images/post/04.jpg" alt="image">
											</div>
											<div class="item-content border-0">
												<p class="item-meta">
													August 25, 2018
												</p>
												<h4>
													<a href="blog-single-right.html">
														Veri Paulo Evertitur Oratio Amet Advers
													</a>
												</h4>
											</div>
										</div>
										<!-- .vertical-item -->
										<div class="vertical-item">
											<div class="item-media">
												<img class="rounded-0" src="images/post/05.jpg" alt="image">
											</div>
											<div class="item-content border-0">
												<p class="item-meta">
													August 23, 2018
												</p>
												<h4>
													<a href="blog-single-right.html">
														Dolor Aliquip Doctus Bonorum Pertinacia
													</a>
												</h4>
											</div>
										</div>
										<!-- .vertical-item -->
										<div class="vertical-item">
											<div class="item-media">
												<img class="rounded-0" src="images/post/04.jpg" alt="image">
											</div>
											<div class="item-content border-0">
												<p class="item-meta">
													August 25, 2018
												</p>
												<h4>
													<a href="blog-single-right.html">
														Veri Paulo Evertitur Oratio Amet Advers
													</a>
												</h4>
											</div>
										</div>
										<!-- .vertical-item -->
										<div class="vertical-item">
											<div class="item-media">
												<img class="rounded-0" src="images/post/05.jpg" alt="image">
											</div>
											<div class="item-content border-0">
												<p class="item-meta">
													August 23, 2018
												</p>
												<h4>
													<a href="blog-single-right.html">
														Dolor Aliquip Doctus Bonorum Pertinacia
													</a>
												</h4>
											</div>
										</div>
										<!-- .vertical-item -->
									</div>
									<!-- .owl-carousel -->
								</div>
								<!-- .widget_slider -->
							</article>


							<div id="comments" class="comments-area">

								<h3 class="comments-title">
									Your Comments
								</h3>

								<ol class="comment-list">
									<li class="comment">
										<article class="comment-body">
											<footer class="comment-meta">
												<div class="comment-author vcard">
													<img alt="img" src="images/post/comment_1.jpg">
												</div>
												<!-- .comment-author -->

												<div class="comment-metadata">
													<a href="#">
														<span>Ethane Forman</span>
													</a>
													<span class="pl-1 pr-1 color-white">/</span>
													<a href="#">
														<time datetime="2018-03-14T07:57:01+00:00">
															August 25, 2018
														</time>
													</a>
													<span class="pl-1 pr-1 color-white">/</span>
													<a href="#">
														<time datetime="2018-03-14T07:57:01+00:00">
															at 5:30 am
														</time>
													</a>
												</div>
												<!-- .comment-metadata -->
											</footer>
											<!-- .comment-meta -->

											<div class="comment-content">
												<p>Mea omnesque complectitur concludaturque ut. Sit ut eirmod moderatius, an sit has habeo lorem, bonorum platonem pro in. Te viderer praesent eos, his et aperiam cum aliquid, vel omnis aliquip ex.</p>
											</div>
											<!-- .comment-content -->

											<div class="reply">
												<a rel="nofollow" class="comment-reply-link" href="#respond">Reply</a>
											</div>
										</article>
										<!-- .comment-body -->
										<ol class="children">
											<li class="comment">
												<article class="comment-body">
													<footer class="comment-meta">
														<div class="comment-author vcard">
															<img alt="img" src="images/post/comment_2.jpg">
														</div>
														<!-- .comment-author -->

														<div class="comment-metadata">
															<a href="#">
																<span>Tiller Gill</span>
															</a>
															<span class="pl-1 pr-1 color-white">/</span>
															<a href="#">
																<time datetime="2018-03-14T07:57:01+00:00">
																	August 26, 2018
																</time>
															</a>
															<span class="pl-1 pr-1 color-white">/</span>
															<a href="#">
																<time datetime="2018-03-14T07:57:01+00:00">
																	at 1:30 am
																</time>
															</a>
														</div>
														<!-- .comment-metadata -->
													</footer>
													<!-- .comment-meta -->

													<div class="comment-content">
														<p>Vel blandit democritum persequeris id, meliore neglegentur pri in, qui cum eros detraxit. Ne assentior intellegat sit. Eros eligendi id his. At pro tale amet iudicabit voluptatum.</p>
													</div>
													<!-- .comment-content -->

													<div class="reply">
														<a rel="nofollow" class="comment-reply-link" href="#respond">Reply</a>
													</div>
												</article>
												<!-- .comment-body -->
												<!-- .children -->
											</li>
											<!-- #comment-## -->
										</ol>
										<!-- .children -->
									</li>
									<!-- #comment-## -->
									<li class="comment">
										<article class="comment-body">
											<footer class="comment-meta">
												<div class="comment-author vcard">
													<img alt="img" src="images/post/comment_3.jpg">
												</div>
												<!-- .comment-author -->

												<div class="comment-metadata">
													<a href="#">
														<span>Jacob Green</span>
													</a>
													<span class="pl-1 pr-1 color-white">/</span>
													<a href="#">
														<time datetime="2018-03-14T07:57:01+00:00">
															August 27, 2018
														</time>
													</a>
													<span class="pl-1 pr-1 color-white">/</span>
													<a href="#">
														<time datetime="2018-03-14T07:57:01+00:00">
															at 3:30 am
														</time>
													</a>
												</div>
												<!-- .comment-metadata -->
											</footer>
											<!-- .comment-meta -->

											<div class="comment-content">
												<p>Quo quem antiopam te, per prima deterruisset cu. At alia veniam verear est. An ludus zril salutandi cum. Habeo docendi et vis, ea vis dicit ignota quaerendum. Quas mundi luptatum sed cu, in per quem affert.</p>
											</div>
											<!-- .comment-content -->

											<div class="reply">
												<a rel="nofollow" class="comment-reply-link" href="#respond">Reply</a>
											</div>
										</article>
										<!-- .comment-body -->
									</li>
									<!-- #comment-## -->
								</ol>
								<!-- .comment-list -->


								<div id="respond" class="comment-respond">
									<h3 id="reply-title" class="comment-reply-title">Write the Comment</h3>
									<form class="" method="post" action="http://webdesign-finder.com/html/modelia/">
										<div class="form-group">
											<input title="name" name="name" type="text" class="form-control" placeholder="full name">
										</div>
										<div class="form-group">
											<input title="phone" name="phone" type="tel" class="form-control" placeholder="phone number">
										</div>
										<div class="form-group">
											<input title="email" name="email" type="email" class="form-control" placeholder="email address">
										</div>
										<div class="form-group">
											<textarea title="message" name="message" cols="30" rows="9" class="form-control" placeholder="your message"></textarea>
											<button type="submit" class="btn-submit"><i class="fa fa-paper-plane" aria-hidden="true"></i></button>
										</div>
									</form>
								</div>
								<!-- #respond -->

							</div>

						</div>
					</div>

				</div>
				<div class="fw-divider-space hidden-below-lg mt-50"></div>
			</section>
@endsection