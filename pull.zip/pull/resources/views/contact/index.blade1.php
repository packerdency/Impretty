@extends('layouts.master')
@section('content')
<div class="container">
    <h4 class="grey-text text-darken-2 center">Message</h4>
      
    <div class="row">
        <!-- Show All Admins List as a Card -->
        <div class="card col s12 m12 l12 xl12">
            <div class="card-content">
                <div class="row">
                    <h5 class="pl-15 grey-text text-darken-2">Message List</h5>
                    <!-- Table that shows Admins List -->
                    <table class="responsive-table col s12 m12 l12 xl12">
                        <thead class="grey-text text-darken-2">
                            <tr>
                                <th>ID</th>
                                <th>Fullname</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Location</th>
                                <th>Message</th>
                                <th>Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($contacts as $contactUs)
                                    <tr>
                                        <td>{{$contactUs->id}}</td>
                                        <td>{{$contactUs->fullname}} </td>
                                        <td>{{$contactUs->email}}</td>
                                        <td>{{$contactUs->phone}}</td>
                                        <td>{{$contactUs->location}}</td>
                                        <td>{{$contactUs->message}}</td>
                                        <td>
                                            <div class="row mb-0">
                                                <div class="col">
                                                    <a href="{{route('contact.show',$contactUs->id)}}" class="btn btn-floating btn-small waves=effect waves-light orange"><i class="material-icons">mode_edit</i></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                {{-- If we are searching then show this link --}}

                        </tbody>
                    </table>
                    <div class="center">
                        {{$contacts->links()}}
                      </div>
                    <!-- Admins Table END -->
                </div>
                <!-- Show Pagination Links -->
            </div>
        </div>
        <!-- Card END -->
    </div>
</div>


<!-- This is the button that is located at the right bottom, that navigates us to admins.create view --> 
@endsection