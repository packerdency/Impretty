@extends('frontend.app')
@section('content')
			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h3>Blog & Events</h3>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Blog 
								</li>
							</ol>
						</div>

					</div>
				</div>
			</section>

			<section class="ds s-pt-70 s-pb-40 s-pb-md-70 s-py-lg-100 s-py-xl-150">
				<div class="container">
					<div class="row c-mb-30">
						<div class="offset-lg-1 col-lg-10">
							<div class="row isotope-wrapper masonry-layout">
								@foreach ($blogs as $blog)
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="{{route('events.show',$blog->id)}}">
												<img src="{{url('/storage/upload')}}/{{($blog->image)}}" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="{{route('events.show',$blog->id)}}" rel="bookmark">
														{{$blog->title}}
													</a>
												</h4>
												<div class="entry-meta">
													<span class="screen-reader-text">Posted on</span>
													<a href="#" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-11T15:15:12+00:00">
															{{ $blog->created_at }}
														</time>
													</a>
												</div>
												<!-- .entry-meta -->
											</header>
											<!-- .entry-header -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								
								@endforeach
							</div>

							<div class="row mt-0">
								<div class="fw-divider-space pt-30"></div>
								<div class="col-sm-12 d-flex justify-content-center mb-0">
									<nav class="navigation pagination mt-0" role="navigation">
										<h2 class="screen-reader-text">Posts navigation</h2>
										<div class="nav-links">
											<a class="prev page-numbers" href="#">
												<i class="fa fa-chevron-left"></i>
												<span class="screen-reader-text">Previous page</span>
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												1
											</a>
											<span class="page-numbers current">
												<span class="meta-nav screen-reader-text">Page </span>
												2
											</span>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												3
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												...
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												12
											</a>
											<a class="next page-numbers" href="#">
												<span class="screen-reader-text">Next page</span>
												<i class="fa fa-chevron-right"></i>
											</a>
										</div>
									</nav>
								</div>
							</div>
						</div>

					</div>

				</div>
			</section>

@endsection