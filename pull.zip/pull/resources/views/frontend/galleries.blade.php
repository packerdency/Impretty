@extends('frontend.app')
@section('content')

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Model Galleries</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="#">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Gallery
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ds s-py-70 s-py-lg-100 s-py-xl-150">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="row isotope-wrapper masonry-layout c-mb-30" data-filters=".gallery-filters">
								@foreach ($galleries as $gallery)
								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="{{url('/storage/upload')}}/{{($gallery->pic)}}" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>
								@endforeach
							</div>
							<!-- .isotope-wrapper-->
						</div>

						<div class="fw-divider-space hidden-below-lg mt-50"></div>
						<div class="fw-divider-space hidden-xs hidden-above-lg mt-30"></div>
					</div>

				</div>
			</section>
@endsection