@extends('frontend.app')
@section('content')
<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h3>Brief History</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        History
                    </li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="ds s-pt-70 s-pb-0 s-pb-sm-70 s-py-lg-100 s-py-xl-150 c-gutter-60 c-mb-50">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <h3> {{ $history->title}}</h3>
                <p class="excerpt">
                    {{ $history->body}}
                </p>
            </div>
            <div class="col-lg-5">

                <div id="accordion01" role="tablist">

                    <div class="card">
                        <div class="card-header" role="tab" id="collapse01_header">
                            <h5>
                                <a data-toggle="collapse" href="#collapse01" aria-expanded="true" aria-controls="collapse01">
                                    <i class="fa fa-television"></i>
                                    Online Webinars
                                </a>
                            </h5>
                        </div>

                        <div id="collapse01" class="collapse show" role="tabpanel" aria-labelledby="collapse01_header" data-parent="#accordion01">
                            <div class="card-body">

                                <div class="media media-top">
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="images/recent_post1.jpg" alt="img">
                                        </a>
                                    </div>
                                    <div class="media-body mt-20">
                                        Consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header" role="tab" id="collapse02_header">
                            <h5>
                                <a class="collapsed" data-toggle="collapse" href="#collapse02" aria-expanded="false" aria-controls="collapse02">
                                    <i class="fa fa-fire"></i>
                                    Radio broadcast
                                </a>
                            </h5>
                        </div>
                        <div id="collapse02" class="collapse" role="tabpanel" aria-labelledby="collapse02_header" data-parent="#accordion01">
                            <div class="card-body">
                                <div class="media media-top">
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="images/recent_post2.jpg" alt="img">
                                        </a>
                                    </div>
                                    <div class="media-body mt-20">
                                        Consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="card">
                        <div class="card-header" role="tab" id="collapse03_header">
                            <h5>
                                <a class="collapsed" data-toggle="collapse" href="#collapse03" aria-expanded="false" aria-controls="collapse03">
                                    <i class="fa fa-users"></i>
                                    Group Trainings
                                </a>
                            </h5>
                        </div>

                        <div id="collapse03" class="collapse" role="tabpanel" aria-labelledby="collapse03_header" data-parent="#accordion01">
                            <div class="card-body">

                                <div class="media media-top">
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="images/recent_post1.jpg" alt="img">
                                        </a>
                                    </div>
                                    <div class="media-body mt-20">
                                        Consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header" role="tab" id="collapse04_header">
                            <h5>
                                <a class="collapsed" data-toggle="collapse" href="#collapse04" aria-expanded="false" aria-controls="collapse04">
                                    <i class="fa fa-user"></i>
                                    Personal Trainings
                                </a>
                            </h5>
                        </div>
                        <div id="collapse04" class="collapse" role="tabpanel" aria-labelledby="collapse04_header" data-parent="#accordion01">
                            <div class="card-body">
                                <div class="media media-top">
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="images/recent_post2.jpg" alt="img">
                                        </a>
                                    </div>
                                    <div class="media-body mt-20">
                                        Consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header" role="tab" id="collapse05_header">
                            <h5>
                                <a class="collapsed" data-toggle="collapse" href="#collapse05" aria-expanded="false" aria-controls="collapse05">
                                    <i class="fa fa-book"></i>
                                    Personal Trainings
                                </a>
                            </h5>
                        </div>
                        <div id="collapse05" class="collapse" role="tabpanel" aria-labelledby="collapse05_header" data-parent="#accordion01">
                            <div class="card-body">
                                <div class="media media-top">
                                    <div class="media-left">
                                        <a href="#">
                                            <img src="images/recent_post1.jpg" alt="img">
                                        </a>
                                    </div>
                                    <div class="media-body mt-20">
                                        Consetetur sadipscing elitr, sed diam nonumy eirmod tempor.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="fw-divider-space hidden-below-lg mt-20"></div>
            </div>
        </div>
    </div>
</section>
@endsection