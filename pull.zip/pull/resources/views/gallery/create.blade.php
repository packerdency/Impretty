@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Add Gallery</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('gallery.store') }}" enctype="multipart/form-data" method="POST">
      @csrf
      <div class="box-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="fname">First Name</label>
              <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" value="{{old('fname')}}">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="lname">Last Name</label>
              <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" value="{{old('lname')}}">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <div class="form-group">
              <label for="w">Weight </label>
              <input type="number" class="form-control" name="w" id="w" placeholder="Weight " value="{{old('w')}}">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="height"> Height</label>
              <input type="number" class="form-control" name="height" id="height" placeholder="Height" value="{{old('height')}}">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="age">Age </label>
              <input type="number" class="form-control" name="age" id="age" placeholder=" Enter Your Age" value="{{old('age')}}">
            </div>
          </div>
          <div class="col-md-3">
            <div class="form-group">
              <label for="hair">Hair </label>
              <input type="text" class="form-control" name="hair" id="hair" placeholder=" Hair Color" value="{{old('hair')}}">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="location"> Location</label>
              <input type="text" class="form-control" name="location" id="location" placeholder="Enter location" value="{{old('location')}}">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="year"> Year</label>
              <input type="number" class="form-control" name="year" id="year" placeholder="Entry Year" value="{{old('year')}}">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="pic">Picture</label>
              <input type="file" id="pic" name="pic" value="{{old('pic')}}">
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
@endsection