@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
     Model Gallery
      <small> Galleries</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Gallery </li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Pic </th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Location</th>
              <th>Weight</th>
              <th>Height </th>
              <th>Age</th>
              <th>Hair </th>
              <th>Year</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($galleries as $gallery)
                <tr>
                    <td>{{ $gallery->id}}</td>
                    <td><img src="{{url('/storage/upload')}}/{{($gallery->pic)}}" width="8%"/></td>
                    <td>{{ $gallery->fname}}</td>
                    <td>{{ $gallery->lname}}</td>
                    <td>{{ $gallery->location}}</td>
                    <td>{{ $gallery->w}}</td>
                    <td>{{ $gallery->height}}</td>
                    <td>{{ $gallery->age}}</td>
                    <td>{{ $gallery->hair}}</td>
                    <td>{{ $gallery->year}}</td>
                    <td>
                      <form action="{{route('gallery.destroy',$gallery->id)}}" method="post">
                        <a href="{{route('gallery.edit',$gallery->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Pic </th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Location</th>
                    <th>Weight</th>
                    <th>Height </th>
                    <th>Age</th>
                    <th>Hair </th>
                    <th>Year</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    {{ $galleries->links() }}
  </section>
@endsection