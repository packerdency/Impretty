@extends('frontend.app')
@section('content')

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>{{$project->title}} </h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="{{ url('/projects') }}">Back</a>
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>


			<section class="ds s-py-70 s-py-lg-100 s-py-xl-150 c-gutter-60">
				<div class="container">
					<div class="row">


						<div class="offset-lg-1 col-lg-10">
							<article class="vertical-item  post type-event status-publish format-standard has-post-thumbnail content-padding border-rad-5">
								<div class="item-media post-thumbnail">
									<img src="{{url('/storage/upload')}}/{{($project->image)}}" alt="img">
								</div>


								<div class="item-content border-0 ds">
									<!-- .post-thumbnail -->
									<header class="entry-header">
										<a href="#" rel="bookmark">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">{{ $project->created_at }}</time>
										</a>
									</header>
									<!-- .entry-header -->

									<div class="entry-content">
										<p class="excerpt">
											{{$project->body}}
										</p>
									</div>
									<!-- .entry-content -->
								</div>
								<!-- .item-content -->
							</article>

						</div>

						<div class="fw-divider-space hidden-below-lg mt-50"></div>
					</div>

				</div>
			</section>
			@endsection