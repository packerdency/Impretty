<li class="header">MENU</li>
<!-- Optionally, you can add icons to the links -->
<li class="active"><a href="{{ route('dashboard') }}"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>

<li><a href="{{ route('about.index') }}"><i class="fa fa-book"></i> <span>About Us</span></a></li>


<li><a href="{{ route('contact.index') }}"><i class="fa fa-envelope"></i> <span>Messages</span></a></li>
<li><a href="{{ route('registration.index') }}"><i class="fa fa-edit"></i> <span>Registrations</span></a></li>
<li><a href="{{ route('proposal.index') }}"><i class="fa fa-edit"></i> <span>Sponsorship Requests </span></a></li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span>History</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('history.create') }}"> Add</a></li>
    <li><a href="{{ route('history.index') }}"> History</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span> Reigning Queen</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('pqueen.create') }}"> Add</a></li>
    <li><a href="{{ route('pqueen.index') }}">Reigning Queen</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span>Past Winners</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('pwinner.create') }}"> Add</a></li>
    <li><a href="{{ route('pwinner.index') }}">Past Winner</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span> Charity Projects</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('project.create') }}"> Create</a></li>
    <li><a href="{{ route('project.index') }}">Project List</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span>Social Media</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('social.create') }}"> Add Account</a></li>
    <li><a href="{{ route('social.index') }}">Account</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-folder"></i> <span>Sponsors</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('sponsor.create') }}"> Add Sponsors</a></li>
    <li><a href="{{ route('sponsor.index') }}">List of Sponsors </a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-pie-chart"></i> <span>Blog</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('blog.create') }}">Add Post</a></li>
    <li><a href="{{ route('blog.index') }}">Posts</a></li>
  </ul>
</li>

<li class="treeview">
  <a href="#"><i class="fa fa-th"></i> <span>Model Gallery</span>
    <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
  </a>
  <ul class="treeview-menu">
    <li><a href="{{ route('gallery.create') }}">Add model</a></li>
    <li><a href="{{ route('gallery.index') }}">Model Galleries</a></li>
  </ul>
</li>
<li class="header">Settings</li>
<li><a href="{{ route('users.create') }}"><i class="fa fa-circle-o text-yellow"></i> <span>Change Password</span></a></li>
<li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Log out</span></a></li>
