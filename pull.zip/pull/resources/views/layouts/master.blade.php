<!DOCTYPE html>
<html class="no-js">

<head>
	<title>{{config('app.name','Impretty')}}</title>
	<meta charset="utf-8">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="{{ asset('frontend/css/bootstrap.min.css') }}">
	<link rel="stylesheet" href="{{ asset('frontend/css/animations.css') }}">
	<link rel="stylesheet" href="{{ asset('frontend/css/font-awesome.css') }}">
	<link rel="stylesheet" href="{{ asset('frontend/css/main.css') }}">
	<link rel="stylesheet" href="{{ asset('frontend/css/shop.css') }}">
	<script src="{{ asset('frontend/js/vendor/modernizr-custom.js') }}"></script>

</head>

<body>

	<div class="preloader">
		<div class="preloader_image pulse"></div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls p-normal">
		</div>
	</div><!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->


			<!-- header with two Bootstrap columns - left for logo and right for navigation and includes (search, social icons, additional links and buttons etc -->
			<header class="page_header ds bottom_mask_add">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-xl-3 col-lg-4 col-md-5 col-11">
							<a href="{{ url('/') }}" class="logo">
								<img src="{{ asset('frontend/images/logo.png') }}" alt="img">
							</a>
						</div>
						<div class="col-xl-6 col-lg-8 col-md-7 col-1">
							<div class="nav-wrap">

								<!-- main nav start -->
								<nav class="top-nav">
									<ul class="nav sf-menu">
                                        
										<li>
											<a href="{{ url('/') }}">Home</a>
										</li>

									<li>
											<a href="{{ url('/aboutUs') }}">About Us</a>
											<ul>
										<li>
										     <a href="{{ url('/histories') }}">History</a>
										</li>

										<li>
											<a href="{{ url('/pqueen') }}">Reigning Beauty Queen</a>
										</li>
										<li>
											<a href="{{ url('/pwinners') }}"> Past Winners</a>
										</li>
											</ul>
										</li>

										<li>
											<a href="{{ url('/howtoenter') }}">Become A Queen</a>
										</li>

										<li>
											<a href="{{ url('/galleries') }}">Gallery</a>
										</li>

										<li>
											<a href="{{ route('contact.create') }}">Contact Us</a>
										</li>
									</ul>
								</nav>
								<!-- eof main nav -->

								<!--hidding includes on small devices. They are duplicated in topline-->

							</div>
						</div>
						<div class="col-xl-3 col-lg-4 col-md-5 col-11">
							<div class="top-includes">
								<ul class="top-includes d-none d-xl-flex">

									<li>
										<a href="{{ route('login') }}">
											<i class="fa fa-user-o" aria-hidden="true"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-calendar" aria-hidden="true"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- header toggler -->
				<span class="toggle_menu"><span></span></span>
            </header>
            
            @yield('content')

            <footer class="page_footer ds spec top_mask_add s-pt-70 s-pb-50 s-pb-lg-100 s-pb-xl-150 c-gutter-60">
                <div class="container">
                    <div class="row">
            
                        <div class="col-md-6 col-xl-5 animate text-left" data-animation="fadeInUp">
                            <img src="{{ asset('frontend/images/logo.png') }}" alt="img">
                            <p class="mt-20">
                                Impretty (I'm pretty) Face Of Beauty Pageant was created to empower young women from all cultures and backgrounds of the country to realize their goals through experiences that build self-confidence and create opportunities for success... 
                            </p>
                        </div>
            
                        <div class="col-md-6 col-xl-3 animate" data-animation="fadeInUp">
                            <h3>Links</h3>
                            <ul class="list1">
                                <li>
                                    <a href="{{ url('/galleries') }}">Our Impretty Queens</a>
                                </li>
                                <li>
                                    <a href="{{ url('/brand') }}">Our Brand</a>
                                </li>
                                <li>
                                    <a href="{{ url('/events') }}">Blog</a>
                                </li>
                                <li>
                                    <a href="{{ url('/partners') }}">Sponsors & Partners</a>
                                </li>
                                <li>
                                    <a href="{{ url('/contact.create') }}">Contact Us</a>
                                </li>
                                <li>
                                    <a href="{{ url('/projects') }}">Our Humanitarian Projects</a>
                                </li>
                                <li>
                                    <a href="{{ url('/terms') }}">Terms & Conditions</a>
                                </li>
                            </ul>
                        </div>
            
                        <div class="col-md-6 col-xl-4 animate" data-animation="fadeInUp">
                            <h3>Follow Us on Social Media</h3>
                            <p class="social-icons ">
                                <a href="{{$socialmedia->facebook}}" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
                                <a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
                                <a href="#" class="fa fa-instagram color-bg-icon rounded" title="instagram"></a>
                                <a href="#" class="fa fa-youtube-play color-bg-icon rounded" title="youtube"></a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
            
            <section class="page_copyright ds ms top_mask_add overflow-visible">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="fw-divider-space hidden-below-md mt-50"></div>
                            <div class="fw-divider-space hidden-above-md mt-20"></div>
                            <p class="text-left"><a target="_blank" href="#">Impretty &copy;2020 | All Rights Reserved</a></p>
                            <div class="fw-divider-space hidden-below-md mt-50"></div>
                            <div class="fw-divider-space hidden-above-md mt-20"></div>
                            </div>
                        </div>
            
                    </div>
                </div>
            </footer>
        </div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="{{ asset('frontend/js/compressed.js') }}"></script>
	<script src="{{ asset('frontend/js/main.js') }}"></script>

	<!-- Google Map Script -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?callback=templateInitGoogleMap&amp;key=AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4"></script>

</body>


<!-- index_singlepage12:56:40  -->
</html>