@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Upload Model</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('model.store') }}" enctype="multipart/form-data" method="POST">
      @csrf
      <div class="box-body">

        <div class="form-group">
          <label for="fname">First Name</label>
          <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name">
        </div>

        <div class="form-group">
          <label for="lname">Last Name</label>
          <input type="text" class="form-control" name="fname" id="fname" placeholder="Last Name">
        </div>

        <div class="form-group">
          <label for="weight">Weight</label>
          <input type="text" class="form-control" name="weight" id="weight" placeholder="Weight">
        </div>

        <div class="form-group">
          <label for="height">Height</label>
          <input type="text" class="form-control" name="height" id="height" placeholder="Height">
        </div>

        <div class="form-group">
          <label for="age">Age</label>
          <input type="text" class="form-control" name="age" id="age" placeholder="Age">
        </div>

        <div class="form-group">
          <label for="hair">Hair</label>
          <input type="text" class="form-control" name="hair" id="hair" placeholder="Hair Color">
        </div>

        <div class="form-group">
          <label for="year">Year</label>
          <input type="text" class="form-control" name="year" id="year" placeholder="Year">
        </div>

        <div class="form-group">
          <label for="image">Image</label>
          <input type="file" id="image" name="pic">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
@endsection