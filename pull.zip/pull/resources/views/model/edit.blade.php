@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Upload Model</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('model.update',$models->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">

        <div class="form-group">
          <label for="fname">First Name</label>
          <input type="text" class="form-control" name="fname" id="fname" value="{{$sponsors->fname}}">
        </div>

        <div class="form-group">
          <label for="lname">Last Name</label>
          <input type="text" class="form-control" name="fname" id="fname" value="{{$sponsors->fname}}">
        </div>

        <div class="form-group">
          <label for="weight">Weight</label>
          <input type="text" class="form-control" name="weight" id="weight" value="{{$sponsors->weight}}">
        </div>

        <div class="form-group">
          <label for="height">Height</label>
          <input type="text" class="form-control" name="height" id="height" value="{{$sponsors->height}}">
        </div>

        <div class="form-group">
          <label for="age">Age</label>
          <input type="text" class="form-control" name="age" id="age" value="{{$sponsors->age}}">
        </div>

        <div class="form-group">
          <label for="hair">Hair</label>
          <input type="text" class="form-control" name="hair" id="hair" value="{{$sponsors->hair}}">
        </div>

        <div class="form-group">
          <label for="year">Year</label>
          <input type="text" class="form-control" name="year" id="year" value="{{$sponsors->year}}">
        </div>

        <div class="form-group">
          <label for="image">Image</label>
          <input type="file" id="image" name="pic" value="{{$sponsors->pic}}">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
@endsection