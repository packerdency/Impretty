@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Impretty Models
      <small>Company Profile</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Models</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Pic </th>
              <th>Weight</th>
              <th>Height </th>
              <th>Age</th>
              <th>Hair </th>
              <th>Year</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($models as $models)
                <tr>
                    <td>{{ $models->id}}</td>
                    <td>{{ $models->fname}}</td>
                    <td>{{ $models->lname}}</td>
                    <td>{{ $models->pic}}</td>
                    <td>{{ $models->w}}</td>
                    <td>{{ $models->height}}</td>
                    <td>{{ $models->age}}</td>
                    <td>{{ $models->hair}}</td>
                    <td>{{ $models->year}}</td>
                    <td>
                      <form action="{{route('model.destroy',$models->id)}}" method="post">
                        <a href="{{route('model.edit',$models->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Pic </th>
                    <th>Weight</th>
                    <th>Height </th>
                    <th>Age</th>
                    <th>Hair </th>
                    <th>Year</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    {{ $models->links() }}
  </section>
@endsection