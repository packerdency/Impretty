@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Change Password</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="#" method="POST">
      @csrf
      <div class="box-body">
        <div class="form-group">
          <label for="password">Current Password</label>
          <input type="password" class="form-control" name="current_password" id="password" placeholder="Enter Current Password">
        </div>
        <div class="form-group">
            <label for="password">New Password</label>
            <input type="password" class="form-control" name="new_password" id="new_password" placeholder="Enter New Password">
          </div>
          <div class="form-group">
            <label for="password">Current Password</label>
            <input type="password" class="form-control" name="new_confirm_password" id="new_confirm_password" placeholder="Repeat New Password">
          </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update Password</button>
      </div>
    </form>
  </div>
@endsection