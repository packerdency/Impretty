@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Queen</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('pqueen.update',$pqueen->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="{{$pqueen->name}}">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="picture">Picture</label>
              <input type="file" id="picture" name="picture" value="{{$pqueen->picture}}">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="facebook">Facebook</label>
              <input type="text" class="form-control" name="facebook" id="facebook" placeholder="Facebook" value="{{$pqueen->facebook}}">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="twitter">Twitter</label>
              <input type="text" class="form-control" name="twitter" id="twitter" placeholder="Twitter" value="{{$pqueen->twitter}}">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="instagram">Instagram</label>
              <input type="text" class="form-control" name="instagram" id="instagram" placeholder="Instagram" value="{{$pqueen->instagram}}">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="body">Body</label>
              <textarea name="body" class="form-control" id="body" >{{$pqueen->body}}</textarea>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection