@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Reigning Queen
      <small> Profile</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Current</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>Name</th>
              <th>Body</th>
              <th>Photo</th>
              <th>Facebook</th>
              <th>Twitter</th>
              <th>Instagram</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($pqueen as $pqueen)
                <tr>
                    <td>{{ $pqueen->name}}</td>
                    <td>{{ $pqueen->body}}</td>
                    <td>{{ $pqueen->picture}}</td>
                    <td>{{ $pqueen->facebook}}</td>
                    <td>{{ $pqueen->twitter}}</td>
                    <td>{{ $pqueen->instagram}}</td>
                    <td>
                      <form action="{{route('pqueen.destroy',$pqueen->id)}}" method="post">
                        <a href="{{route('pqueen.edit',$pqueen->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Body</th>
                    <th>Photo</th>
                    <th>Facebook</th>
                    <th>Twitter</th>
                    <th>Instagram</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
  </section>
@endsection