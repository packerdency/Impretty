@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Project Post</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('project.update', $project->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="{{$project->title}}">
        </div>
        <div class="form-group">
          <label for="body">Body</label>
          <textarea name="body" class="form-control" id="body" cols="30" rows="10">{{ $project->body}}</textarea>
        </div>
        <div class="form-group">
          <label for="image">Cover Image</label>
          <input type="file" id="image" name="image" value="{{old('cover_image')}}">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection