@extends('frontend.app')
@section('content')
<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h1></h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Partnership Registration</a>
                    </li>
                </ol>
            </div>

        </div>
    </div>
</section>
<section class="ds casting s-py-70 s-py-lg-100 s-py-xl-150">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-lg-10 offset-lg-1 c-gutter-20">
                <h3>Please Apply By Filling This Form</h3>
                @if ($message = Session::get('success'))

                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>{{ $message }}</strong>
                </div>
                @endif
            
                @if (count($errors) > 0)
            
                    <div class="alert alert-danger">
                        <strong>Whoops!</strong> There were some problems with your input.
                        <ul>
                            @foreach ($errors->all() as $error)
            
                                <li>{{ $error }}</li>
            
                            @endforeach
                        </ul>
                    </div>
            
                @endif
                <form class="pt-10" action="{{route('proposal.store')}}" enctype="multipart/form-data" method="POST" >
                    @csrf
                    <div class="row ">
                        <div class="col-lg-6">
                            <h3>Sponsors & Partners</h3>
                            <div id="accordion01" role="tablist">
                                <div class="card">
									<div class="card-header" role="tab" id="collapse01_header">
										<h5>
											<a data-toggle="collapse" href="#collapse01" aria-expanded="true" aria-controls="collapse01">
												Interested?
											</a>
										</h5>
									</div>

									<div id="collapse01" class="collapse show" role="tabpanel" aria-labelledby="collapse01_header" data-parent="#accordion01">
										<div class="card-body">
                                            We appreciate all interested sponsors and partners for your kind gesture and support										</div>
									</div>
								</div>
                               </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <input type="text" name="company" placeholder="Company/Individual Name " class="form-control" value="{{old('company')}}">
                            </div>
                            <div class="form-group">
                                <input type="tel" name="phone" placeholder="phone number" class="form-control" value="{{old('phone')}}">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" placeholder="Official Email Address" class="form-control" value="{{old('email')}}">
                            </div>
                            <div class="form-group">
                                <input type="text" name="city" placeholder="City" class="form-control" value="{{old('city')}}">
                            </div>
                            <div class="form-group">
                                <input type="text" name="country" placeholder="Country" class="form-control" value="{{old('country')}}">
                            </div>
                            <div class="form-group">
                                <textarea name="message" id="message" cols="30" rows="10" placeholder="Message" class="form-control" value="{{old('message')}}"></textarea>
                            </div>
                            <button type="submit" class="btn-maincolor">submit</button>
                        </div>
                    </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <div class="fw-divider-space hidden-below-lg mt-40"></div>
</section>
@endsection