@extends('frontend.app')
@section('content')
			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">
						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>
						<div class="col-md-12 text-center">
							<h1></h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>
			<section class="ds casting s-py-70 s-py-lg-100 s-py-xl-150">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-lg-10 offset-lg-1 c-gutter-20">
							<h3>Please Fill This Registration Form</h3>
							@if ($message = Session::get('success'))
							<div class="alert alert-success alert-block">
								<button type="button" class="close" data-dismiss="alert">×</button>
									<strong>{{ $message }}</strong>
							</div>
							@endif						
							@if (count($errors) > 0)
								<div class="alert alert-danger">
									<strong>Whoops!</strong> There were some problems with your input.
									<ul>
										@foreach ($errors->all() as $error)
											<li>{{ $error }}</li>				
										@endforeach
									</ul>
								</div>
							@endif
							<form class="pt-10" action="{{ route('registration.store') }}" enctype="multipart/form-data" method="POST" >
								@csrf
								<div class="row ">
									<div class="col-lg-6">
										<div class="form-group">
											<input type="text" name="name" id="name" placeholder="full name" class="form-control" value="{{old('name')}}">
										</div>
										<div class="form-group">
											<input type="tel" name="phone" id="phone" placeholder="phone number" class="form-control" value="{{old('phone')}}">
										</div>
										<div class="form-group">
											<input type="text" name="age" id="age" placeholder="your age" class="form-control" value="{{old('age')}}">
										</div>
										<div class="form-group">
											<input type="date" name="dob" id="dob" placeholder="Date of Birth" class="form-control" value="{{old('dob')}}">
										</div>
										<div class="form-group">
											<input type="text" name="weight" id="weight" placeholder="Weight" class="form-control" value="{{old('weight')}}">
										</div>
										<div class="form-group">
											<input type="text" name="occupation" id="occupation" placeholder="OCCUPATION" class="form-control" value="{{old('occupation')}}">
										</div>
										<div class="form-group">
											<input type="text" name="location" id="location" placeholder="Location" class="form-control" value="{{old('location')}}">
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<input type="email" name="email" id="email" placeholder="email address" class="form-control" value="{{old('email')}}">
										</div>
										<div class="form-group">
											<input type="text" name="hobbies" id="hobbies" placeholder=" HOBBIES" class="form-control" value="{{old('hobbies')}}">
										</div>
										<div class="form-group">
											<input type="tel" name="parentNumber" id="parentNumber" placeholder="PARENT'S OR GUARDIAN'S PHONE NUMBER " class="form-control" value="{{old('parentNumber')}}">
										</div>
										<div class="form-group">
											<input type="text" name="highschool" id="highschool" placeholder="HIGH SCHOOL ATTENDED" class="form-control" value="{{old('highschool')}}">
										</div>

										<div class="form-group">
											<input type="text" name="height" id="height" placeholder="Height" class="form-control" value="{{old('height')}}">
										</div>
										<div class="form-group">
											<input type="text" name="hair" id="hair" placeholder="Hair" class="form-control" value="{{old('hair')}}">
										</div>

										<div class="form-group">
											<input type="text" name="localLanguage" id="localLanguage" placeholder="DO YOU SPEAK ANY NIGERIAN LANGAUGE" class="form-control" value="{{old('localLanguage')}}">
										</div>
									</div>

									<div class="col-12 mt-20">
										<div class="form-group">
											<textarea name="address" id="address" placeholder=" Address" class="form-control">{{old('address')}}</textarea>
										</div>
										<div class="form-group">
											<textarea name="gain" id="gain" placeholder="WHAT DO YOU HOPE TO GAIN BY PARTICIPATING IN IMPRETTY FACE OF BEAUTY PAGEANT?" class="form-control">{{old('gain')}}</textarea>
										</div>
										<div class="form-group">
											<textarea name="goal" id="goal" placeholder="TELL US ABOUT A GOAL YOU RECENTLY ACCOMPLISHED " class="form-control">{{old('goal')}}</textarea>
										</div>
									</div>
								</div>
								<div class="fw-divider-space hidden-below-lg mt--10"></div>
								<div class="row checkboxs">
									<div class="fw-divider-space hidden-below-lg mt--10"></div>

									<div class="col-12 mt-20">
										<div class="form-group">
											<textarea name="aboutMe" id="aboutMe" placeholder="About Me" class="form-control" value="{{old('aboutMe')}}"></textarea>
										</div>
										<div class="form-group">
											<label for="name"> Passport:</label>
											<input type="file" name="passport" id="passport" class="form-control" value="{{old('passport')}}">
										</div>
										<div class="form-group">
											<label for="name"> ID Card:</label>
											<input type="file" name="idcard" id="idcard" class="form-control" value="{{old('idcard')}}">
										</div>
										<div class="form-group">
											<label for="name"> Birth Certificate:</label>
											<input type="file" name="birthCert" id="birthCert" class="form-control" value="{{old('birthCert')}}">
										</div>
										<input type="checkbox" id="agreement" name="agreement" value="agreement"><label class="mt-40" for="agreement">I Agree to Impretty Terms and Conditions</label>
									</div>
									<div class="form-group mt-30">
										<button type="submit" class="btn-maincolor">submit</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="fw-divider-space hidden-below-lg mt-40"></div>
			</section>
@endsection