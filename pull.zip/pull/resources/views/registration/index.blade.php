@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
     Entries
      <small>registration</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Registration</li>
    </ol>
    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Names</th>
              <th>Phone</th>
              <th>Age </th>
              <th>Location</th>
              <th>Email Address</th>
              <th>Height </th>
              <th>Passport</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($registrations as $registration)
                <tr>
                    <td>{{ $registration->id}}</td>
                    <td>{{ $registration->name}}</td>
                    <td>{{ $registration->phone}}</td>
                    <td>{{ $registration->age}}</td>
                    <td>{{ $registration->location}}</td>
                    <td>{{ $registration->email}}</td>
                    <td> {{ $registration->height}}</td>
                    <td> <img src="{{url('/storage/upload')}}/{{( $registration->passport)}}" width="25%"/></td>
                    <td>
                      <form action="{{route('registration.destroy',$registration->id)}}" method="post">
                        <a href="{{route('registration.show',$registration->id)}}" class="btn btn-sm btn-success"><i class="fa fa-folder-open"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Names</th>
                    <th>Phone</th>
                    <th>Age </th>
                    <th>Location</th>
                    <th>Email Address</th>
                    <th>Height </th>
                    <th>Passport</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    {{ $registrations->links() }}
  </section>
@endsection