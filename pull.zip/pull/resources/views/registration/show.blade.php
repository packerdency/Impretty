@extends('layouts.app')
@section('content')

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Details
        <small>#007612</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i> Impretty Beauty Pageant
            <small class="pull-right">Date: 2/10/2014</small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          <address>
            <strong>Impretty</strong><br>
            Email: info@imprettyworld.com
          </address>
        </div>

        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Name</th>
              <th>Number</th>
              <th>Email</th>
              <th>Hobbies</th>
              <th>Age</th>
              <th>Parent Number</th>
              <th>Date of Birth</th>
              <th>High Sch</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>{{ $registration->name}}</td>
              <td>{{ $registration->phone}}</td>
              <td>{{ $registration->email}}</td>
              <td>{{ $registration->hobbies}}</td>
              <td>{{ $registration->age}}</td>
              <td> {{ $registration->parentNumber}}</td>
              <td> {{ $registration->dob}}</td>
              <td> {{ $registration->highschool}}</td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Weight</th>
              <th>Height</th>
              <th>Occupation</th>
              <th>Location</th>
              <th>Hair</th>
              <th>LocalLanguage</th>
              <th>Address</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>{{ $registration->weight}}</td>
              <td>{{ $registration->height}}</td>
              <td>{{ $registration->occupation}}</td>
              <td>{{ $registration->location}}</td>
              <td>{{ $registration->hair}}</td>
              <td> {{ $registration->localLanguage}}</td>
              <td> {{ $registration->address}}</td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Your Gain</th>
              <th>About Me</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>{{ $registration->gain}}</td>
              <td>{{ $registration->aboutMe}}</td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Passport</th>
              <th>ID Card</th>
              <th>Birth Cert</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><img src="{{url('/storage/upload')}}/{{( $registration->passport)}}" width="50%"/></td>
              <td><img src="{{url('/storage/upload')}}/{{( $registration->idcard)}}" width="50%"/></td>
              <td><img src="{{url('/storage/upload')}}/{{( $registration->birthCert)}}" width="50%"/></td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Your Goal</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td>{{ $registration->goal}}</td>
            </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
        </div>
      </div>
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
 
  @endsection