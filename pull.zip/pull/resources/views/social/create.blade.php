@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Socail Media</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('social.store') }}" enctype="multipart/form-data" method="POST">
      @csrf
      <div class="box-body">
        <div class="form-group">
          <label for="facebook">Facebook</label>
          <input type="text" class="form-control" name="facebook" id="facebook" placeholder=" Enter Facebook Name" value="{{old('facebook')}}">
        </div>

        <div class="form-group">
          <label for="twitter">Twitter</label>
          <input type="text" class="form-control" name="twitter" id="twitter" placeholder=" Enter Twitter Handle" value="{{old('twitter')}}">
        </div>

        <div class="form-group">
          <label for="instagram">Instagram</label>
          <input type="text" class="form-control" name="instagram" id="instagram" placeholder=" Enter Instagram Name" value="{{old('instagram')}}">
        </div>

        <div class="form-group">
          <label for="youtube">Youtube</label>
          <input type="text" class="form-control" name="youtube" id="youtube" placeholder=" Enter Youtube Link" value="{{old('youtube')}}">
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
@endsection