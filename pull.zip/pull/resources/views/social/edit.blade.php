@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Socail Media</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('social.update',$socialmedia->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">
        <div class="form-group">
          <label for="facebook">Facebook</label>
          <input type="text" class="form-control" name="facebook" id="facebook" value="{{$socialmedia->facebook}}">
        </div>

        <div class="form-group">
          <label for="twitter">Twitter</label>
          <input type="text" class="form-control" name="twitter" id="twitter" value="{{$socialmedia->twitter}}">
        </div>

        <div class="form-group">
          <label for="instagram">Instagram</label>
          <input type="text" class="form-control" name="instagram" id="instagram" value="{{$socialmedia->instagram}}">
        </div>

        <div class="form-group">
          <label for="youtube">Youtube</label>
          <input type="text" class="form-control" name="youtube" id="youtube" value="{{$socialmedia->youtube}}">
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection