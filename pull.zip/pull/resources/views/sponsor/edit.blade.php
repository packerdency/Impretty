@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Partners</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    @if ($errors ->any())
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        @foreach ($errors as $error)
      <li>{{$error}}</li>
        @endforeach
      </ul>
    </div>
    @endif
    <form action="{{ route('sponsor.update',$sponsors->id) }}" enctype="multipart/form-data" method="POST">
      @csrf
      @method('PUT')
      <div class="box-body">
        <div class="form-group">
          <label for="sponsor">Sponsor Name</label>
        <input type="text" class="form-control" name="name" id="name" value="{{$sponsors->name}}">
        </div>

        <div class="form-group">
          <label for="logo">Image</label>
          <input type="file" id="logo" name="logo" value="{{$sponsors->image}}">
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection