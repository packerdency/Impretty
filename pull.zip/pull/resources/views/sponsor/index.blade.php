@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Our Partner
      <small>Sponsors</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active"> PArtner</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Sponsors</th>
              <th>Logo</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($sponsors as $sponsor)
                <tr>
                    <td>{{ $sponsor->id}}</td>
                    <td>{{ $sponsor->name}}</td>
                    <td><img src="{{url('/storage/upload')}}/{{( $sponsor->logo)}}" width="15%"/></td>
                    <td>
                      <form action="{{route('sponsor.destroy',$sponsor->id)}}" method="post">
                        <a href="{{route('sponsor.edit',$sponsor->id)}}" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Sponsors</th>
                    <th>Logo</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    {{ $sponsors->links() }}
  </section>
@endsection