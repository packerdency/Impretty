@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit About</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form">
      <div class="box-body">
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" id="title" name="title" placeholder="Title">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Body</label>
          <textarea name="body" class="form-control" id="body" cols="30" rows="10"></textarea>
        </div>
        <div class="form-group">
          <label for="image">Image</label>
          <input type="file" id="image">
        </div>
        <div class="form-group">
            <label for="signature">Signature</label>
            <input type="file" id="signature" name="signature">
          </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
@endsection