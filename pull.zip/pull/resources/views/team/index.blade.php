@extends('layouts.app')
@section('content')
<section class="content-header">
    <h1>
      Team
      <small>Company staffs</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Team</li>
    </ol>

    @if ($message = Session::get('success'))

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong>{{ $message }}</strong>
    </div>
    @endif

    @if (count($errors) > 0)

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                @foreach ($errors->all() as $error)

                    <li>{{ $error }}</li>

                @endforeach
            </ul>
        </div>

    @endif

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Full Name</th>
              <th>Postion</th>
              <th>Facebook </th>
              <th>Twitter</th>
              <th>Instagram</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                @foreach($team as $team)
                <tr>
                    <td>{{ $team->id}}</td>
                    <td>{{ $team->fullname}}</td>
                    <td>{{ $team->position}}</td>
                    <td>{{ $team->facebook}}</td>
                    <td>{{ $team->twitter}}</td>
                    <td>{{ $team->instagram}}</td>
                    <td> {{ $team->image}}</td>
                    <td>
                      <form action="" method="post">
                        <a href="#" class="btn btn-warning">Edit</a><a href="#" class="btn btn-danger">Delete</a>
                      </form>
                    </td>
                  </tr>
                  @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Full Name</th>
                    <th>Postion</th>
                    <th>Facebook </th>
                    <th>Twitter</th>
                    <th>Instagram</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>

  </section>
@endsection