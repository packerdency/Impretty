@extends('layouts.app')
@section('content')
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Change Password</h3>
    </div>
    @if(Session::has('success'))
    <div class="alert alert-success">
        {!! Session::get('success') !!}
    </div>
    @endif
    @if(Session::has('failure'))
    <div class="alert alert-danger">
        {!! Session::get('failure') !!}
    </div> 
    @endif
    <form action="{{ route('password.update') }}" method="POST">
      @csrf
      <div class="box-body">
      <div class="form-group{{$errors->has('old') ? 'has-error': '' }}">
          <label for="password">Old Password</label>
          <input type="password" class="form-control" name="old" id="password" placeholder="Enter Old Password">
          @if($errors->has('old'))<span class="help-block">
          <strong>{{ $errors->first('old') }}</strong>
          </span>
          @endif
        </div>
        <div class="form-group{{$errors->has('password') ? 'has-error': '' }}">
            <label for="password">New Password</label>
            <input type="password" class="form-control" name="password" id="password" placeholder="Enter New Password">
            @if($errors->has('password'))<span class="help-block">
                <strong>{{ $errors->first('password') }}</strong>
                </span>
                @endif
          </div>
          <div class="form-group{{$errors->has('password_confirmation') ? 'has-error': '' }}">
            <label for="password-confirm">Current Password</label>
            <input type="password" class="form-control" name="password_confirmation" id="password_confirm" placeholder="Repeat New Password">
            @if($errors->has('password_confirmation'))<span class="help-block">
                <strong>{{ $errors->first('password_confirmation') }}</strong>
                </span>
                @endif
          </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update Password</button>
      </div>
    </form>
  </div>
@endsection