<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/','FrontendController@index');

Route::get('aboutUs', function () {
    return view('frontend.aboutUs');
});

Route::get('events', function () {
    return view('events');
});

Route::get('galleries', function () {
    return view('frontend.galleries');
});

Route::get('howtoenter', function () {
    return view('frontend.howtoenter');
});

Route::get('partners', function () {
    return view('frontend.partners');
});

Route::get('brand', function () {
    return view('frontend.brand');
});

Route::get('histories', function () {
    return view('frontend.histories');
});

Route::get('pqueen', function () {
    return view('frontend.pqueens');
});

Route::get('pwinners', function () {
    return view('frontend.pwinners');
});

Route::get('projects', function () {
    return view('frontend.projects');
});

Route::get('terms', function () {
    return view('frontend.terms');
});

Auth::routes();

Auth::routes(['verify' => true, 'register' => false]);

/*
Route::get('changePassword', function () {
    return view('changePassword');
});
Route::get('change-password','ChangePasswordController@index');
Route::get('change-password','ChangePasswordController@store')->name('change.password');
*/
Route::get('/dashboard', 'HomeController@index')->name('dashboard');



Route::get('/changePassword','HomeController@showChangePasswordForm');

Route::resource('registration','RegistrationController');
Route::get('/prnpriview','RegistrationController@prnpriview');

//Route::resource('sponsorrequest','SponsorrequestController');

Route::resource('about','AboutController');
Route::resource('aboutUs','AboutUsController');

Route::resource('proposal','ProposalController');

Route::resource('contact','ContactController');

Route::resource('model','ModelsController');

Route::resource('social','SocialmediaController');

Route::resource('team','TeamController');

Route::resource('gallery','GalleryController');
Route::resource('galleries','GalleriesController');

Route::resource('blog','BlogController');
Route::resource('events','EventsController');

Route::resource('history','HistoryController');
Route::resource('histories','HistoriesController');

Route::resource('sponsor','SponsorsController');
Route::resource('partners','PartnerController');

Route::resource('pwinner','PwinnerController');
Route::resource('pwinners','PwinnersController');

Route::resource('pqueen','PqueenController');
Route::resource('currentQueen','CurrentQueenController');

Route::resource('project','ProjectController');
Route::resource('projects','ProjectsController');

Route::resource('users', 'Auth\UpdatePasswordController');
/*
Route::get('change-password', 'Auth\UpdatePasswordController@index')->name('password.form');
Route::post('change-password','Auth\UpdatePasswordController@update')->name('password.update');
*/