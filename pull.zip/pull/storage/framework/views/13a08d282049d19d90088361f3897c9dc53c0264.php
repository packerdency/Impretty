<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1></h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>

			<section class="ds casting s-py-70 s-py-lg-100 s-py-xl-150">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-50"></div>
						<div class="fw-divider-space hidden-above-lg mt-20"></div>

						<div class="col-xs-12 col-lg-10 offset-lg-1 c-gutter-20">
							<h3>Please Fill This Registration Form</h3>
							<?php if($errors ->any()): ?>
							<div class="alert alert-danger">
							  <strong>Whoops!</strong> They were some problems with your inputs. <br>
							  <ul>
								<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <li><?php echo e($error); ?></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							  </ul>
							</div>
							<?php endif; ?>
							<form class="pt-10" action="<?php echo e(route('registration-store')); ?>" enctype="multipart/form-data" method="POST" >
								<?php echo csrf_field(); ?>
								<div class="row ">
									<div class="col-lg-6">
										<div class="form-group">
											<input type="text" name="name" placeholder="full name" class="form-control">
										</div>
										<div class="form-group">
											<input type="tel" name="phone" placeholder="phone number" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="age" placeholder="your age" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="dob" placeholder="Date of Birth" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="weight" placeholder="Weight" class="form-control">
										</div>
										<div class="form-group">
											<select name='input_11'  class='form-control' ><option value='' >OCCUPATION</option>
												<option value='SELF-EMPLOYED' >SELF-EMPLOYED</option>
												<option value='EMPLOYEE' >EMPLOYEE</option>
												<option value='BUSINESS-OWNER' >BUSINESS-OWNER</option>
												<option value='OTHERS' >OTHERS</option>
											</select>
										</div>
										<div class="form-group">
											<input type="text" name="location" placeholder="Location" class="form-control">
										</div>
									</div>
									<div class="col-lg-6">
										<div class="form-group">
											<input type="email" name="email" placeholder="email address" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="HOBBIES" placeholder=" HOBBIES" class="form-control">
										</div>
										<div class="form-group">
											<input type="tel" name="parent-number" placeholder="PARENT'S OR GUARDIAN'S PHONE NUMBER " class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="highschool" placeholder="HIGH SCHOOL ATTENDED" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="university" placeholder="UNIVERSITY ATTENDED " class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="height" placeholder="Height" class="form-control">
										</div>
										<div class="form-group">
											<input type="text" name="hair" placeholder="Hair" class="form-control">
										</div>
										<div class="form-group">
											<select name='input_11'  class='form-control' ><option value='' >DO YOU SPEAK ANY NIGERIAN LANGAUGE</option>
												<option value='YES' >YES</option>
												<option value='NO' >NO</option>
											</select>
										</div>
									</div>

									<div class="col-12 mt-20">
										<div class="form-group">
											<textarea name="address" id="address" placeholder=" Address" class="form-control"></textarea>
										</div>
										<div class="form-group">
											<textarea name="gain" id="gain" placeholder="WHAT DO YOU HOPE TO GAIN BY PARTICIPATING IN MISS NIGERIA 2019?" class="form-control"></textarea>
										</div>
										<div class="form-group">
											<textarea name="goal" id="goal" placeholder="TELL US ABOUT A GOAL YOU RECENTLY ACCOMPLISHED " class="form-control"></textarea>
										</div>
									</div>

								</div>
								<div class="fw-divider-space hidden-below-lg mt--10"></div>
								<h6>WHERE WOULD YOU PREFER TO BE AUDITIONED</h6>
								<div class="row checkboxs">
									<div class="col-lg-12">
										<div class="form-group">
											<input type="checkbox" id="lagos" name="lagos" value="lagos"><label class="color-dark-font" for="lagos"> Lagos</label>
										</div>
										<div class="form-group">
											<input type="checkbox" id="abuja" name="abuja" value="abuja"><label class="color-dark-font" for="abuja">Abuja </label>
										</div>
									</div>

									<div class="fw-divider-space hidden-below-lg mt--10"></div>
									<h6>HAVE YOU EVER COMPETED IN A BEAUTY PAGEANT BEFORE?</h6>
									<div class="row checkboxs">
										<div class="col-lg-12">
											<div class="form-group">
												<input type="checkbox" id="yes" name="yes" value="Yes"><label class="color-dark-font" for="yes"> YES</label>
											</div>
											<div class="form-group">
												<input type="checkbox" id="no" name="no" value="no"><label class="color-dark-font" for="no">NO </label>
											</div>
											<div class="form-group">
												<textarea name="pageant" id="pageant" placeholder=" IF YES, PLEASE SPECIFY" class="form-control"></textarea>
											</div>
										</div>

									<div class="col-12 mt-20">
										<div class="form-group">
											<textarea name="about_user" id="about_user" placeholder="about me" class="form-control"></textarea>
										</div>
										<div class="form-group">
											<label for="name"> Passport:</label>
											<input type="file" name="image" class="form-control">
										</div>
										<div class="form-group">
											<label for="name"> ID Card:</label>
											<input type="file" name="idcard"  class="form-control">
										</div>
										<div class="form-group">
											<label for="name"> Birth Certificate:</label>
											<input type="file" name="birth" class="form-control">
										</div>
									</div>
								</div>
								<input type="checkbox" id="agreement" name="agreement" value="agreement"><label class="mt-40" for="agreement">I Agree to Modelia Terms and Conditions</label>
								<div class="form-group mt-30">
									<button type="submit" class="btn-maincolor">submit</button>
								</div>
							</form>
						</div>
					</div>

				</div>
				<div class="fw-divider-space hidden-below-lg mt-40"></div>
			</section>

			<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="<?php echo e(asset('frontend/js/compressed.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

</body>


<!-- casting12:57:10  -->
</html>