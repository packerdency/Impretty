<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Edit Partners</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <?php if($errors ->any()): ?>
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('sponsor.update',$sponsors->id)); ?>" enctype="multipart/form-data" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="box-body">
        <div class="form-group">
          <label for="sponsor">Sponsor Name</label>
        <input type="text" class="form-control" name="name" id="name" value="<?php echo e($sponsors->name); ?>">
        </div>

        <div class="form-group">
          <label for="logo">Image</label>
          <input type="file" id="logo" name="logo" value="<?php echo e($sponsors->image); ?>">
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>