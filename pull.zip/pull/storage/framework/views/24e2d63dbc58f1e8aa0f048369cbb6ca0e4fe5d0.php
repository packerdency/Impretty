<?php $__env->startSection('content'); ?>
<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h1>Reigning Beauty Queen</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="index.html">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Current Queen
                    </li>
                </ol>
            </div>
        </div>
    </div>
</section>


<section class="ds gallery-single s-py-70 s-py-lg-100 s-py-xl-150">
    <div class="container">
        <div class="row">

            <div class="col-lg-10 offset-lg-1">

                <div class="vertical-item text-left content-padding border-rad-5">
                    <div class="item-media">
                        <div class="owl-carousel buttons-type" data-loop="true" data-margin="0" data-nav="true" data-dots="false" data-themeclass="entry-thumbnail-carousel" data-center="false" data-items="1" data-autoplay="true" data-responsive-xs="1" data-responsive-sm="1" data-responsive-md="1" data-responsive-lg="1">
                            <a href="<?php echo e(asset('frontend/images/gallery/gallery_single1.jpg')); ?>" class="photoswipe-link" data-width="1170" data-height="780">
                                <img src="<?php echo e(asset('frontend/images/gallery/gallery_single1.jpg')); ?>" alt="img">
                            </a>
                        </div>
                    </div>
                    <div class="item-content ds">
                        <h2 class="title h-1">
                            Jessica Barnes
                        </h2>
                        <p>
                            Jessica Barnes is a native Miamian and has been in casting since 1992. Her love of the arts and actors has contributed to her success in casting. She has an undergraduate degree from the University of Miami.
                        </p>
                        <p class="social-icons text-center pt-20">
                            <a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
                            <a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
                            <a href="#" class="fa fa-instagram color-bg-icon rounded" title="instagram"></a>
                        </p>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <div class="fw-divider-space hidden-below-lg mt-70"></div>
    <div class="fw-divider-space hidden-above-lg mt-30"></div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>