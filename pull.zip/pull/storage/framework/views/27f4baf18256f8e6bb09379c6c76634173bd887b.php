<?php $__env->startSection('content'); ?>

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>About Us</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									About Us
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ds hello-section s-pt-60 s-pb-110 s-pt-md-75 s-pb-md-130 s-pb-lg-0 s-pt-xl-165 s-pb-xl-100 overflow-visible s-overlay s-mobile-overlay">
				<div class="container">
					<div class="row justify-content-end">
						<div class="col-xs-12 col-lg-6">
							<h4 class="big-title">
								<?php echo e($about->title); ?>

							</h4>
							<div class="fw-divider-space hidden-below-lg mt-45"></div>
							<p class="color-white font-main">
								<?php echo e($about->body); ?>

							</p>
						</div>
					</div>
					<div class="fw-divider-space hidden-below-lg mt-30"></div>
				</div>
				<div class="fw-divider-space hidden-below-lg pt-100"></div>
			</section>

			<section class="blockquote-section about-section ds s-pb-190 s-pt-130 s-pb-md-150 s-pt-md-45 s-pb-xl-250 s-pt-xl-150 overflow-visible ">
				<div class="fw-divider-space hidden-below-md pt-60"></div>
				<div class="container animate" data-animation="fadeIn">
					<div class="row">
						<div class="col-xs-12 col-lg-10 offset-lg-1">
							<div class="owl-carousel buttons-type home" data-loop="true" data-margin="0" data-nav="true" data-dots="false" data-themeclass="entry-thumbnail-carousel" data-center="false" data-items="1" data-autoplay="false" data-responsive-xs="1" data-responsive-sm="1" data-responsive-md="1" data-responsive-lg="1">
								<div class="item text-center">
									<div class="entry-meta mt-0">
										<span class="byline">
											<span class="author d-flex flex-column align-items-center vcard">
												<span class="title">OUR MISSION</span>
											</span>
										</span>
									</div>
									<div class="entry-content">
										<p class="quote">
											Our mission is to provide women who participate annually a platform to effect positive change personally, professionally and philanthropically as inspirational leaders and role models. We celebrate beauty, all forms of it and provide the tools that help women to feel their most beautiful: "Confidently Beautiful". The winner possess positive qualities of a define beauty queen and she serves as a role model to young women in the country.
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="fw-divider-space hidden-below-md pt-60"></div>
			</section>

			
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>