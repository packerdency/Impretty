<?php $__env->startSection('content'); ?>
<section class="page_title ds bottom_mask_subtract s-pt-30 s-pb-25 pattern-background">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-215"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12">
                <h1 class="small-title">The Brand</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Brand
                    </li>
                </ol>
            </div>

            <div class="fw-divider-space hidden-below-lg mt-215"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

        </div>
    </div>
</section>

<section class="ds c-gutter-60 s-pt-70 s-pb-30 s-pt-md-100 s-pb-md-80 s-pt-xl-150 s-pb-xl-200">
    <div class="container">
        <div class="row">

            <div class="col-lg-8">
                <div class="vertical-item ">
                    <div class="item-content">
                        <h4> Our Brand </h4>
                        <p>Looking good has before now be part of our daily activities but looking stunning is what Impretty products will do for you. Impretty products helps you looks exquisite, feel good and get more out of you. Impretty is geared towards giving customers full satisfaction with regular development and production of high quality products. We have a wide range of high and best quality of all hair products with the latest and best possible price for every African woman; Braids, Weaves, Crochet. And we have best quality cosmetics.</p>                       
                    </div>
                </div>
            </div>

            <aside class="col-lg-4 affix-aside">
                <div class="widget widget_categories">

                    <h3 class="widget-title"></h3>

                    <ul>

                    </ul>
                </div>


            </aside>

        </div>
        <div class="fw-divider-space hidden-below-lg mt-30"></div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>