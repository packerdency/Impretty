<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Team
      <small>Company staffs</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Team</li>
    </ol>

    <?php if($message = Session::get('success')): ?>

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    <?php endif; ?>

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Full Name</th>
              <th>Postion</th>
              <th>Facebook </th>
              <th>Twitter</th>
              <th>Instagram</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($team->id); ?></td>
                    <td><?php echo e($team->fullname); ?></td>
                    <td><?php echo e($team->position); ?></td>
                    <td><?php echo e($team->facebook); ?></td>
                    <td><?php echo e($team->twitter); ?></td>
                    <td><?php echo e($team->instagram); ?></td>
                    <td> <?php echo e($team->image); ?></td>
                    <td>
                      <form action="" method="post">
                        <a href="#" class="btn btn-warning">Edit</a><a href="#" class="btn btn-danger">Delete</a>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Full Name</th>
                    <th>Postion</th>
                    <th>Facebook </th>
                    <th>Twitter</th>
                    <th>Instagram</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>