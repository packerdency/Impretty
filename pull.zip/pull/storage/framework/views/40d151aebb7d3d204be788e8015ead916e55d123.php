<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title"> Edit Blog Post</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <?php if($errors ->any()): ?>
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('blog.update',$blog->id)); ?>" enctype="multipart/form-data" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="box-body">
        <div class="form-group">
          <label for="title">Title</label>
        <input type="text" class="form-control" name="title" id="title" value="<?php echo e($blog->title); ?>">
        </div>
        <div class="form-group">
          <label for="description">Description</label>
          <textarea name="description" class="form-control" id="description" cols="30" rows="10"><?php echo e($blog->description); ?></textarea>
        </div>
        <div class="form-group">
          <label for="image">Blog Image</label>
          <input type="file" id="image" name="image" value="<?php echo e($blog->image); ?>">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>