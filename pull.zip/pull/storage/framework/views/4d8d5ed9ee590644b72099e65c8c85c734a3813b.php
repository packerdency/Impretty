<?php $__env->startSection('content'); ?>
			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Blog Grid</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Blog Grid
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>

			<section class="ds s-pt-70 s-pb-40 s-pb-md-70 s-py-lg-100 s-py-xl-150">
				<div class="container">

					<div class="row c-mb-30">
						<div class="offset-lg-1 col-lg-10">
							<div class="row isotope-wrapper masonry-layout">
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/01.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Repudiandae sint velit vero voluptas
													</a>
												</h4>
												<div class="entry-meta">
													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-11T15:15:12+00:00">March 11,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->
											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Accusamus ad adipisci alias culpa deleniti ducimus, est et ex fugiat iusto laudantium.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/02.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Consectetur adipisicing elit
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-15T15:15:12+00:00">March 15,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A alias et voluptas.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->

								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/03-big.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														A alias et magni maxime mollitia
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">March 18,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Amet aut debitis deserunt dolor dolorem harum in, inventore magnam.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>

								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/04.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Repudiandae sint velit vero voluptas
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-11T15:15:12+00:00">March 11,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Asperiores aut autem deserunt distinctio eius enim et ex fuga hic laudantium.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/05.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Consectetur adipisicing elit
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-15T15:15:12+00:00">March 15,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>A amet, architecto aut delectus expedita harum neque perspiciatis quaerat.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/06.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														A alias et magni maxime mollitia
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">March 18,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Adipisci asperiores assumenda, blanditiis cum cumque dolor, ea ratione!</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/07-big.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Repudiandae sint velit vero voluptas
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-11T15:15:12+00:00">March 11,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Aperiam consequuntur culpa dolorem fugit, nisi quos? Accusamus, aliquam!</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/08.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Consectetur adipisicing elit
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-15T15:15:12+00:00">March 15,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Consectetur adipisicing elit. Atque error ipsa nihil placeat! A dolor fugiat ipsam laborum vitae!</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/blog/09.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														A alias et magni maxime mollitia
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">March 18,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Aliquid commodi consequuntur deleniti eius iste nisi sapiente voluptates. Cum...</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/post/02.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Repudiandae sint velit vero voluptas
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-11T15:15:12+00:00">March 11,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Cumque et neque qui quos tenetur! Ab atque cupiditate excepturi id in iste placeat vel!</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/post/01.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														Consectetur adipisicing elit
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-15T15:15:12+00:00">March 15,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. A alias et voluptas.</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
								<div class="col-xl-4 col-md-6">
									<article class="vertical-item text-center content-padding padding-small bordered post type-post status-publish format-standard has-post-thumbnail">
										<div class="item-media post-thumbnail">
											<a href="blog-single-full.html">
												<img src="images/post/03.jpg" alt="img">
											</a>
										</div><!-- .post-thumbnail -->
										<div class="item-content">
											<header class="entry-header">
												<h4 class="entry-title">
													<a href="blog-single-full.html" rel="bookmark">
														A alias et magni maxime mollitia
													</a>
												</h4>
												<div class="entry-meta">


													<span class="screen-reader-text">Posted on</span>
													<a href="blog-single-full.html" rel="bookmark">
														<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">March 18,
															2018
														</time>
													</a>
												</div>
												<!-- .entry-meta -->

											</header>
											<!-- .entry-header -->

											<div class="entry-content">
												<p>Aperiam asperiores aut beatae dolorem ex excepturi, fugiat, id inventore...</p>
											</div><!-- .entry-content -->
										</div><!-- .item-content -->
									</article><!-- #post-## -->
								</div>
							</div>

							<div class="row mt-0">
								<div class="fw-divider-space pt-30"></div>
								<div class="col-sm-12 d-flex justify-content-center mb-0">
									<nav class="navigation pagination mt-0" role="navigation">
										<h2 class="screen-reader-text">Posts navigation</h2>
										<div class="nav-links">
											<a class="prev page-numbers" href="#">
												<i class="fa fa-chevron-left"></i>
												<span class="screen-reader-text">Previous page</span>
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												1
											</a>
											<span class="page-numbers current">
												<span class="meta-nav screen-reader-text">Page </span>
												2
											</span>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												3
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												...
											</a>
											<a class="page-numbers" href="#">
												<span class="meta-nav screen-reader-text">Page </span>
												12
											</a>
											<a class="next page-numbers" href="#">
												<span class="screen-reader-text">Next page</span>
												<i class="fa fa-chevron-right"></i>
											</a>
										</div>
									</nav>
								</div>
							</div>
						</div>

					</div>

				</div>
			</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>