<?php $__env->startSection('content'); ?>
			<section class="ds s-overlay ds soon s-py-70 s-py-lg-100 s-py-xl-150 page_title">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-70"></div>
						<div class="fw-divider-space hidden-above-lg mt-30"></div>

						<div class="col-sm-12 text-center">
							<h2 class="special-heading">
								HOW TO APPLY!
							</h2>

							
							<h6><b>REGISTRATION PROCESS :-</b> </h6>
							<p>Fill and Print out the registration form after you have clicked submit. After registration, every applied contestants will be contacted and always updated on the step next. </p>
							<h6><b>Selected Contestants :-</b></h6> 
							<p>Contestants will be selected by majority votes among every applied contestants and all the selected contestants gets to attend Impretty Face of Beauty Pageantry. </p>
                            <h6><b>Live Face Of Beauty Pageantry :-</b></h6>
							<p>Short interview video of the selected contestant.</p>
							<p>Voting/Judging process.</p>
							<p> Winner announcement.</p>
						                                                                                                                                                                                                           
							<h6><b>CRITERIA -</b></h6>
							<h6>All participants must:</h6>
							<p>Be between the ages of 18 and 26 years old</p>
							<p>Be Nigerian female citizens</p>
							<p>Must not be married, mothers or pregnant</p>
							<p>Must be able to speak fluent English</p>
							<p>Must not have tattoos or piercings</p>

							<h6><b>Note:-</b>DOCUMENTS TO BE PRESENTED ON THE DAY OF PAGEANTRY</h6>
							 
							<P>* Any Nigerian ID card and selected contestants print out form.</P> 
							
						</div>
						<div class="fw-divider-space hidden-below-lg mt-55"></div>
						<div class="fw-divider-space hidden-above-lg mt-20"></div>
						<div class="col-12 text-center">
							<a class="btn-maincolor" href="<?php echo e(route('registration.create')); ?>">Click to Register</a>
						<div class="fw-divider-space hidden-below-lg mt-100"></div>
						<div class="fw-divider-space hidden-above-lg mt-30"></div>
					</div>

				</div>
			</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>