<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Team</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Team
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>

			<section class="ds team s-pt-70 s-pb-50 s-py-lg-100 s-py-xl-150 c-mb-30">
				<div class="container">
					<div class="row">
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_1.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Esther Sommers</a>
									</h4>

									<p class="color-main">
										Talent Advisor
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_2.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Bobbie McKeever</a>
									</h4>

									<p class="color-main">
										Financial Executive
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_3.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Odis Fannin</a>
									</h4>

									<p class="color-main">
										Event Manager
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_4.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Lucy Harris</a>
									</h4>

									<p class="color-main">
										Photographer
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_5.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Gabriel Scott</a>
									</h4>

									<p class="color-main">
										founder
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->
						<div class="col-lg-4 col-md-6">

							<div class="vertical-item box-shadow content-padding text-center border-rad-5">
								<div class="item-media">
									<img src="images/team/face_6.jpg" alt="img">
									<div class="media-links">
										<a class="abs-link" title="" href="team-single.html"></a>
									</div>
								</div>
								<div class="item-content">
									<h4 class="tile">
										<a href="team-single.html">Ronda Baker</a>
									</h4>

									<p class="color-main">
										Photographer
									</p>

									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p>

								</div>
							</div>
						</div><!-- .col-* -->

					</div>

				</div>
				<div class="fw-divider-space hidden-below-lg mt-30"></div>
			</section>

			<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="<?php echo e(asset('frontend/js/compressed.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

</body>


<!-- team12:57:24  -->
</html>