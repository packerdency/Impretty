<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
     Entries
      <small>registration</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Registration</li>
    </ol>
    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Names</th>
              <th>Phone</th>
              <th>Age </th>
              <th>Location</th>
              <th>Email Address</th>
              <th>Height </th>
              <th>Passport</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($registration->id); ?></td>
                    <td><?php echo e($registration->name); ?></td>
                    <td><?php echo e($registration->phone); ?></td>
                    <td><?php echo e($registration->age); ?></td>
                    <td><?php echo e($registration->location); ?></td>
                    <td><?php echo e($registration->email); ?></td>
                    <td> <?php echo e($registration->height); ?></td>
                    <td> <img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $registration->passport)); ?>" width="25%"/></td>
                    <td>
                      <form action="<?php echo e(route('registration.destroy',$registration->id)); ?>" method="post">
                        <a href="<?php echo e(route('registration.show',$registration->id)); ?>" class="btn btn-sm btn-success"><i class="fa fa-folder-open"></i></a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Names</th>
                    <th>Phone</th>
                    <th>Age </th>
                    <th>Location</th>
                    <th>Email Address</th>
                    <th>Height </th>
                    <th>Passport</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    <?php echo e($registrations->links()); ?>

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>