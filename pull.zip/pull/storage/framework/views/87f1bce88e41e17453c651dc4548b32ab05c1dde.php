<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>About Us</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="index.html">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									About Us
								</li>
							</ol>
						</div>

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

					</div>
				</div>
			</section>

			<section class="ds hello-section s-pt-60 s-pb-110 s-pt-md-75 s-pb-md-130 s-pb-lg-0 s-pt-xl-165 s-pb-xl-100 overflow-visible s-overlay s-mobile-overlay">
				<div class="container">
					<div class="row justify-content-end">
						<div class="col-xs-12 col-lg-6">
							<h4 class="big-title">
								hello!
							</h4>
							<div class="fw-divider-space hidden-below-lg mt-45"></div>
							<p class="color-white font-main">
								Modelia, established in 1990, is one of the world's top model agencies, representing some of the fashion industry's most successful faces.
							</p>
							<p>
								A dedicated team of highly experienced professionals have enabled Modelia to sustain its success and dominate the fashion world for over three decades. We are one of the world's top model agencies, representing most successful faces.
							</p>
							<img src="images/signature.png" alt="signature">
							<div class="fw-divider-space hidden-below-lg mt-75"></div>
							<div class="fw-divider-space hidden-above-lg mt-30"></div>
							<a href="contact.html" class="btn btn-outline-maincolor">become a model</a>
							<a href="casting.html" class="btn btn-maincolor">Schedule Casting</a>
						</div>
					</div>
					<div class="fw-divider-space hidden-below-lg mt-30"></div>
				</div>
				<div class="fw-divider-space hidden-below-lg pt-100"></div>
			</section>

			<section class="blockquote-section about-section ds s-pb-190 s-pt-130 s-pb-md-150 s-pt-md-45 s-pb-xl-250 s-pt-xl-150 overflow-visible ">
				<div class="fw-divider-space hidden-below-md pt-60"></div>
				<div class="container animate" data-animation="fadeIn">
					<div class="row">
						<div class="col-xs-12 col-lg-10 offset-lg-1">
							<div class="owl-carousel buttons-type home" data-loop="true" data-margin="0" data-nav="true" data-dots="false" data-themeclass="entry-thumbnail-carousel" data-center="false" data-items="1" data-autoplay="false" data-responsive-xs="1" data-responsive-sm="1" data-responsive-md="1" data-responsive-lg="1">
								<div class="item text-center">
									<div class="entry-meta mt-0">
										<span class="byline">
											<span class="author d-flex flex-column align-items-center vcard">
												<img class="avatar mb-2 rounded-circle" src="images/comment_2.jpg" alt="img">
												<span class="title">Wayne Fernandez</span>
												<a class="url fn n" href="blog-full.html">Photographer</a>
											</span>
										</span>
									</div>
									<div class="entry-content">
										<p class="quote">
											Truly one of my favorite agencies. Your talent is so great and your agency is so professional. It’s such a pleasure to come there! Thank you for being a company that I count on!
										</p>
									</div>
								</div>
								<div class="item text-center">
									<div class="entry-meta mt-0">
										<span class="byline">
											<span class="author d-flex flex-column align-items-center vcard">
												<img class="avatar mb-2 rounded-circle" src="images/comment_1.jpg" alt="img">
												<span class="title">Pearl Hansen</span>
												<a class="url fn n" href="blog-full.html">National Model</a>
											</span>
										</span>
									</div>
									<div class="entry-content">
										<p class="quote">
											I started taking classes at models and images when I was 16 and they've worked to help me launch my career since the day I walked into their door. Much love for them!
										</p>
									</div>
								</div>
								<div class="item text-center">
									<div class="entry-meta mt-0">
										<span class="byline">
											<span class="author d-flex flex-column align-items-center vcard">
												<img class="avatar mb-2 rounded-circle" src="images/comment_3.jpg" alt="img">
												<span class="title">Pearl Hansen</span>
												<a class="url fn n" href="blog-full.html">Manager</a>
											</span>
										</span>
									</div>
									<div class="entry-content">
										<p class="quote">
											uModels agency is a great place to go if you want to learn about the modeling industry, work with amazing people, and gain experience that will last a lifetime.
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="fw-divider-space hidden-below-md pt-60"></div>
			</section>

			<section class="team-section ds s-pt-60 s-pt-md-40 s-pt-xl-150 s-pb-sm-100  s-pb-md-100 s-pb-lg-100 s-pb-xl-100">
				<div class="fw-divider-space hidden-below-md pt-50"></div>
				<div class="container">
					<div class="row">
						<div class="col-12 flex-column">
							<div class="team-slider-shortcode">
								<div class="team-slider-item active">
									<div class="team-profession">Talent Advisor</div>
									<div class="team-slider-image animated fadeInLeft from-right">
										<img src="images/team/team_1.png" alt="team-slide">
									</div>
									<div class="team-slider-name">
										<h3 class="slide-title">
											<span>Esther Sommers</span>
										</h3>
									</div><!-- eof .team-slider-name -->
									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p><!-- eof .social-icons -->
								</div><!-- eof .team-slider-item -->
								<div class="team-slider-item">
									<div class="team-profession">Financial Executive</div>
									<div class="team-slider-image animated fadeInRight from-left">
										<img src="images/team/team_2.png" alt="team-slide">
									</div>
									<div class="team-slider-name">
										<h3 class="slide-title">
											<span>Bobbie McKeever</span>
										</h3>
									</div><!-- eof .team-slider-name -->
									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p><!-- eof .social-icons -->
								</div><!-- eof .team-slider-item -->
								<div class="team-slider-item">
									<div class="team-profession">Event Manager</div>
									<div class="team-slider-image animated fadeInLeft from-right">
										<img src="images/team/team_3.png" alt="team-slide">
									</div>
									<div class="team-slider-name">
										<h3 class="slide-title">
											<span>Odis Fannin</span>
										</h3>
									</div><!-- eof .team-slider-name -->
									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p><!-- eof .social-icons -->
								</div><!-- eof .team-slider-item -->
								<div class="team-slider-item">
									<div class="team-profession">Photographer</div>
									<div class="team-slider-image animated fadeInRight from-left">
										<img src="images/team/team_4.png" alt="team-slide">
									</div>
									<div class="team-slider-name">
										<h3 class="slide-title">
											<span>Lucy Harris</span>
										</h3>
									</div><!-- eof .team-slider-name -->
									<p class="social-icons">
										<a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
										<a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
										<a href="#" class="fa fa-google color-bg-icon rounded" title="google"></a>
									</p><!-- eof .social-icons -->
								</div><!-- eof .team-slider-item -->
							</div>
						</div>
					</div>
				</div>
			</section>


			<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="<?php echo e(asset('frontend/js/compressed.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

</body>


<!-- about12:56:57  -->
</html>