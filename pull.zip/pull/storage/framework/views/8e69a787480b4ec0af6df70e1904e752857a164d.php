<!DOCTYPE html>
<html class="no-js">

<head>
	<title><?php echo e(config('app.name','Impretty')); ?></title>
	<meta charset="utf-8">
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/animations.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('frontend/css/main.css')); ?>">
	<script src="<?php echo e(asset('frontend/js/vendor/modernizr-custom.js')); ?>"></script>

</head>

<body>

	<div class="preloader">
		<div class="preloader_image pulse"></div>
	</div>

	<!-- Unyson messages modal -->
	<div class="modal fade" tabindex="-1" role="dialog" id="messages_modal">
		<div class="fw-messages-wrap ls p-normal">
		</div>
	</div><!-- eof .modal -->

	<!-- wrappers for visual page editor and boxed version of template -->
	<div id="canvas">
		<div id="box_wrapper">

			<!-- template sections -->


			<!-- header with two Bootstrap columns - left for logo and right for navigation and includes (search, social icons, additional links and buttons etc -->
			<header class="page_header ds bottom_mask_add">
				<div class="container-fluid">
					<div class="row align-items-center">
						<div class="col-xl-3 col-lg-4 col-md-5 col-11">
							<a href="<?php echo e(url('/')); ?>" class="logo">
								<img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="img">
							</a>
						</div>
						<div class="col-xl-6 col-lg-8 col-md-7 col-1">
							<div class="nav-wrap">

								<!-- main nav start -->
								<nav class="top-nav">
									<ul class="nav sf-menu">
                                        
										<li>
											<a href="<?php echo e(url('/')); ?>">Home</a>
										</li>

									<li>
											<a href="<?php echo e(url('/aboutUs')); ?>">About Us</a>
											<ul>
										<li>
										     <a href="<?php echo e(url('/history')); ?>">History</a>
										</li>

										<li>
											<a href="<?php echo e(url('/pqueens')); ?>">Reigning Beauty Queen</a>
										</li>
										<li>
											<a href="<?php echo e(url('/pwinners')); ?>"> Past Winners</a>
										</li>
											</ul>
										</li>

										<li>
											<a href="<?php echo e(url('/howtoenter')); ?>">Become A Queen</a>
										</li>

										<li>
											<a href="<?php echo e(url('/galleries')); ?>">Gallery</a>
										</li>

										<li>
											<a href="<?php echo e(route('contact.create')); ?>">Contact Us</a>
										</li>
									</ul>
								</nav>
								<!-- eof main nav -->

								<!--hidding includes on small devices. They are duplicated in topline-->

							</div>
						</div>
						<div class="col-xl-3 col-lg-4 col-md-5 col-11">
							<div class="top-includes">
								<ul class="top-includes d-none d-xl-flex">

									<li>
										<a href="<?php echo e(route('login')); ?>">
											<i class="fa fa-user-o" aria-hidden="true"></i>
										</a>
									</li>
									<li>
										<a href="#">
											<i class="fa fa-calendar" aria-hidden="true"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- header toggler -->
				<span class="toggle_menu"><span></span></span>
			</header>