<?php $__env->startSection('content'); ?>
<section class="content-header">
    <h1>
      Our Partner
      <small>Sponsors</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active"> PArtner</li>
    </ol>

    <?php if($message = Session::get('success')): ?>

    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>

        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

    <?php endif; ?>

    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
              <th>ID </th>
              <th>Sponsors</th>
              <th>Logo</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sponsor->id); ?></td>
                    <td><?php echo e($sponsor->name); ?></td>
                    <td><img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $sponsor->logo)); ?>" width="15%"/></td>
                    <td>
                      <form action="<?php echo e(route('sponsor.destroy',$sponsor->id)); ?>" method="post">
                        <a href="<?php echo e(route('sponsor.edit',$sponsor->id)); ?>" class="btn btn-sm btn-warning"><i class="fa fa-edit"></i></a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                    </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>ID </th>
                    <th>Sponsors</th>
                    <th>Logo</th>
                    <th>Actions</th>
                </tr>
                </tfoot>
    </table>
    <?php echo e($sponsors->links()); ?>

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>