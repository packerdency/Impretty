<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Details
        <small>#007612</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">details</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="invoice">
      <!-- title row -->
      <div class="row">
        <div class="col-xs-12">
          <h2 class="page-header">
            <i class="fa fa-globe"></i> Impretty Beauty Pageant
            <small class="pull-right">Date: 2/10/2014</small>
          </h2>
        </div>
        <!-- /.col -->
      </div>
      <!-- info row -->
      <div class="row invoice-info">
        <div class="col-sm-4 invoice-col">
          <address>
            <strong>Impretty</strong><br>
            Email: info@imprettyworld.com
          </address>
        </div>

        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- Table row -->
      <div class="row">
        <div class="col-xs-12 table-responsive">
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Name</th>
              <th>Number</th>
              <th>Email</th>
              <th>Hobbies</th>
              <th>Age</th>
              <th>Parent Number</th>
              <th>Date of Birth</th>
              <th>High Sch</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><?php echo e($registration->name); ?></td>
              <td><?php echo e($registration->phone); ?></td>
              <td><?php echo e($registration->email); ?></td>
              <td><?php echo e($registration->hobbies); ?></td>
              <td><?php echo e($registration->age); ?></td>
              <td> <?php echo e($registration->parentNumber); ?></td>
              <td> <?php echo e($registration->dob); ?></td>
              <td> <?php echo e($registration->highschool); ?></td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Weight</th>
              <th>Height</th>
              <th>Occupation</th>
              <th>Location</th>
              <th>Hair</th>
              <th>LocalLanguage</th>
              <th>Address</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><?php echo e($registration->weight); ?></td>
              <td><?php echo e($registration->height); ?></td>
              <td><?php echo e($registration->occupation); ?></td>
              <td><?php echo e($registration->location); ?></td>
              <td><?php echo e($registration->hair); ?></td>
              <td> <?php echo e($registration->localLanguage); ?></td>
              <td> <?php echo e($registration->address); ?></td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Your Gain</th>
              <th>About Me</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><?php echo e($registration->gain); ?></td>
              <td><?php echo e($registration->aboutMe); ?></td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Passport</th>
              <th>ID Card</th>
              <th>Birth Cert</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $registration->passport)); ?>" width="50%"/></td>
              <td><img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $registration->idcard)); ?>" width="50%"/></td>
              <td><img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $registration->birthCert)); ?>" width="50%"/></td>
            </tr>
            </tbody>
          </table>
          <table class="table table-striped">
            <thead>
            <tr>
              <th>Your Goal</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><?php echo e($registration->goal); ?></td>
            </tr>
            </tbody>
          </table>
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <!-- this row will not appear when printing -->
      <div class="row no-print">
        <div class="col-xs-12">
          <a href="#" target="_blank" class="btn btn-default"><i class="fa fa-print"></i> Print</a>
          <button type="button" class="btn btn-primary pull-right" style="margin-right: 5px;">
            <i class="fa fa-download"></i> Generate PDF
          </button>
        </div>
      </div>
    </section>
    <!-- /.content -->
    <div class="clearfix"></div>
 
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>