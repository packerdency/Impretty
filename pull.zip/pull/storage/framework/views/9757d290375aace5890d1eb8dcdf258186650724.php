<?php $__env->startSection('content'); ?>
			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Contact Us</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="#">Home</a>
								</li>
								<li class="breadcrumb-item active">
									Contact Us
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ds">
				<section class="ds ms page_map top_mask_subtract" data-draggable="false" data-scrollwheel="false">

					<div class="marker">
						<div class="marker-address">USA, 301 S Christopher Columbus Blvd, Philadelphia, PA 19106</div>
						<div class="marker-description">
							<span>
								316 Tipple Road Philadelphia, PA 19143
							</span>
						</div>

						<img class="marker-icon" src="images/map_marker_icon.png" alt="img">
					</div>
					<!-- .marker -->

				</section>
				<section class="top_mask_add background-contact s-py-70 s-py-lg-100 s-py-xl-150 c-gutter-30">
					<div class="container">
						<div class="row c-mb-20">
							<div class="col-sm-4 animate" data-animation="pullDown">
								<div class="media media-top">
									<div class="icon-styled text-center bg-maincolor rounded">
										<i class="fa fa-phone"></i>
									</div>
									<p>
										<strong>Phone:</strong> +12 345 678 9123<br>
										<strong>Fax:</strong> +12 345 678 9123
									</p>
								</div>
							</div>
							<div class="col-sm-4 animate" data-animation="pullDown">
								<div class="media media-top">
									<div class="icon-styled text-center bg-maincolor rounded">
										<i class="fa fa-map-marker"></i>
									</div>
									<p>
										PO Box 54378<br>
										4321 Your Address,<br>
										Your City, Your Country
									</p>
								</div>
							</div>
							<div class="col-sm-4 animate" data-animation="pullDown">
								<div class="media media-top">
									<div class="icon-styled text-center bg-maincolor rounded">
										<i class="fa fa-envelope-o"></i>
									</div>
									<p>
										<a href="mailto:info@example.com">info@example.com</a>
									</p>
								</div>
							</div>
						</div>
						<div class="fw-divider-space hidden-below-lg mt-40"></div>
						<div class="fw-divider-space hidden-above-lg mt-20"></div>
						<div class="row">
							<div class="col-12 animate" data-animation="scaleAppear">
								<div class="ds s-parallax s-overlay s-map-dark p-30">

									<?php if($message = Session::get('success')): ?>

									<div class="alert alert-success alert-block">
										<button type="button" class="close" data-dismiss="alert">×</button>
											<strong><?php echo e($message); ?></strong>
									</div>
									<?php endif; ?>
								
									<?php if(count($errors) > 0): ?>
								
										<div class="alert alert-danger">
											<strong>Whoops!</strong> There were some problems with your input.
											<ul>
												<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								
													<li><?php echo e($error); ?></li>
								
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</div>
								
									<?php endif; ?>

									<form action="<?php echo e(route('contact.store')); ?>" class="c-mb-20 c-gutter-20" method="POST" >
										<?php echo csrf_field(); ?>
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<input type="text" name="fullname" id="fullname" class="form-control" placeholder="Full Name" value="<?php echo e(old('fullname')); ?>">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<input type="email" name="email" id="email" class="form-control" placeholder="Email Address" value="<?php echo e(old('email')); ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone Number" value="<?php echo e(old('phone')); ?>">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<input type="text" name="location" id="location" class="form-control" placeholder="Your Location" value="<?php echo e(old('location')); ?>">
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-sm-12">
												<div class="form-group">
													<textarea rows="6" cols="45" name="message" id="message" class="form-control" placeholder="Your Message" value="<?php echo e(old('message')); ?>"></textarea>
													<button type="submit" class="btn-submit"><i class="fa fa-paper-plane"></i></button>
												</div>
											</div>

										</div>
									</form>
								</div>
							</div>
							<!--.col-* -->
						</div>
						<div class="fw-divider-space hidden-below-lg mt-50"></div>
						<div class="fw-divider-space hidden-xs hidden-above-lg mt-20"></div>
					</div>
				</section>
			</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>