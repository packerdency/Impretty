<footer class="page_footer ds spec top_mask_add s-pt-70 s-pb-50 s-pb-lg-100 s-pb-xl-150 c-gutter-60">
    <div class="container">
        <div class="row">

            <div class="col-md-6 col-xl-5 animate text-left" data-animation="fadeInUp">
                <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="img">
                <p class="mt-20">
                    Impretty (I'm pretty) Face Of Beauty Pageant was created to empower young women from all cultures and backgrounds of the country to realize their goals through experiences that build self-confidence and create opportunities for success... 
                </p>
            </div>

            <div class="col-md-6 col-xl-3 animate" data-animation="fadeInUp">
                <h3>Links</h3>
                <ul class="list1">
                    <li>
                        <a href="<?php echo e(url('/galleries')); ?>">Our Impretty Queens</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/brand')); ?>">Our Brand</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/blog')); ?>">Blog</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/partners')); ?>">Sponsors & Partners</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/contact.create')); ?>">Contacts</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/projects')); ?>">Our Humanitarian Projects</a>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/terms')); ?>">Terms & Conditions</a>
                    </li>
                </ul>
            </div>

            <div class="col-md-6 col-xl-4 animate" data-animation="fadeInUp">
                <h3>Follow Us on Social Media</h3>
                <p class="social-icons ">
                    <a href="#" class="fa fa-facebook color-bg-icon rounded" title="facebook"></a>
                    <a href="#" class="fa fa-twitter color-bg-icon rounded" title="twitter"></a>
                    <a href="#" class="fa fa-instagram color-bg-icon rounded" title="instagram"></a>
                    <a href="#" class="fa fa-youtube-play color-bg-icon rounded" title="youtube"></a>
                    <a href="#" class="fa fa-google-plus color-bg-icon rounded" title="google"></a>
                </p>
            </div>
        </div>
    </div>
</footer>

<section class="page_copyright ds ms top_mask_add overflow-visible">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-12">
                <div class="fw-divider-space hidden-below-md mt-50"></div>
                <div class="fw-divider-space hidden-above-md mt-20"></div>
                <p class="text-left"><a target="_blank" href="#">Impretty &copy;2020 | All Rights Reserved</a></p>
                <div class="fw-divider-space hidden-below-md mt-50"></div>
                <div class="fw-divider-space hidden-above-md mt-20"></div>
                </div>
            </div>

        </div>
    </div>
</footer>