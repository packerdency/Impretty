<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Change Password</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <?php if($errors ->any()): ?>
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form action="#" method="POST">
      <?php echo csrf_field(); ?>
      <div class="box-body">
        <div class="form-group">
          <label for="cPass">Current Password</label>
          <input type="password" class="form-control" name="cPass" id="cPass" placeholder="Enter Current Password">
        </div>
        <div class="form-group">
            <label for="nPass">New Password</label>
            <input type="password" class="form-control" name="nPass" id="nPass" placeholder="Enter New Password">
          </div>
          <div class="form-group">
            <label for="nPass">Current Password</label>
            <input type="password" class="form-control" name="nPass" id="nPass" placeholder="Repeat New Password">
          </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Change Password</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>