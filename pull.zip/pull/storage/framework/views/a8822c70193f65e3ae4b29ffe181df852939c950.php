<?php $__env->startSection('content'); ?>
<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h1>Our Partners and Sponsors</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Partners and Sponsors
                    </li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="ds service s-pt-70 s-pb-20 s-pb-sm-70 s-py-lg-100 s-py-xl-150 c-mb-50">
    <div class="container">
        <div class="row">

            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/01.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>

                    <div class="item-content">
                        <h4>
                            <a href="#">Gubergren</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/02.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Takimata</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/03-big.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Amet Consetetur</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/04.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Dolore Magna</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/05.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Accusam</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/06.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Takimata Sanctus</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/07-big.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Elitr</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/08.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Tempor Invidunt</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item text-center">
                    <div class="item-media">
                        <img src="<?php echo e(asset('frontend/images/blog/09.jpg')); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="#"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4>
                            <a href="#">Voluptua</a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>