<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Create Current Queen</h3>
    </div>
    <!-- /.box-header -->
    <!-- form start -->
    <?php if($errors ->any()): ?>
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('pqueen.store')); ?>" enctype="multipart/form-data" method="POST">
      <?php echo csrf_field(); ?>
      <div class="box-body">
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" name="name" id="name" placeholder="Name" value="<?php echo e(old('name')); ?>">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="picture">Picture</label>
              <input type="file" id="picture" name="picture" value="<?php echo e(old('picture')); ?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="form-group">
              <label for="facebook">Facebook</label>
              <input type="text" class="form-control" name="facebook" id="facebook" placeholder="Facebook" value="<?php echo e(old('facebook')); ?>">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="twitter">Twitter</label>
              <input type="text" class="form-control" name="twitter" id="twitter" placeholder="Twitter" value="<?php echo e(old('twitter')); ?>">
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
              <label for="instagram">Instagram</label>
              <input type="text" class="form-control" name="instagram" id="instagram" placeholder="Instagram" value="<?php echo e(old('instagram')); ?>">
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="form-group">
              <label for="body">Body</label>
              <textarea name="body" class="form-control" id="body" ><?php echo e(old('body')); ?></textarea>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>