<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Create Blog Post</h3>
    </div>
    <?php if($errors ->any()): ?>
    <div class="alert alert-danger">
      <strong>Whoops!</strong> They were some problems with your inputs. <br>
      <ul>
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    
     <form action="<?php echo e(route('blog.store')); ?>" enctype="multipart/form-data" method="POST">
      <?php echo csrf_field(); ?>
      <div class="box-body">
        <div class="form-group">
          <label for="title">Title</label>
          <input type="text" class="form-control" name="title" id="title" placeholder="Title" value="<?php echo e(old('title')); ?>">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Description</label>
          <textarea name="description" class="form-control" id="description" cols="30" rows="10" value="<?php echo e(old('description')); ?>"></textarea>
        </div>
        <div class="form-group">
          <label for="image">Image</label>
          <input type="file" id="image" name="image" value="<?php echo e(old('image')); ?>">
        </div>
      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
     </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>