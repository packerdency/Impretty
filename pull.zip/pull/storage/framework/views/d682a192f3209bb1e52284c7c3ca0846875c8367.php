<?php $__env->startSection('content'); ?>

<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h1>Past Winners</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Past Winners</a>
                    </li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="ds s-pt-70 s-pb-80 s-py-md-100 s-py-xl-150">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3>List of our past beauty queens</h3>
            </div>
            <div class="col-lg-12">
                <form class="woocommerce-cart-form" action="#" method="post">

                    <table class="shop_table shop_table_responsive cart">
                        <thead>
                            <tr>
                                <th class="product-name">Name</th>
                                <th class="product-quantity">Year</th>
                            </tr>
                        </thead>
                        <tbody>

                            <tr class="cart_item">
                                <td class="product-name" data-title="Product">
                                    <a href="#">Premium Quality</a>
                                </td>

                                <td class="product-price" data-title="Price">
                                    <span class="amount">
                                        <span></span>12.00
                                    </span>
                                </td>

                            </tr>
                            <tr class="cart_item">
                                <td class="product-name" data-title="Product">
                                    <a href="shop-product-right.html">Woo Ninja</a>
                                </td>

                                <td class="product-price" data-title="Price">
                                    <span class="amount">
                                        <span>$</span>15.00
                                    </span>
                                </td>
                            </tr>
                            <tr class="cart_item">

                                <td class="product-name" data-title="Product">
                                    <a href="shop-product-right.html">Woo Album #3</a>
                                </td>

                                <td class="product-price" data-title="Price">
                                    <span class="amount">
                                        <span>$</span>9.00
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
    <div class="fw-divider-space hidden-below-lg mt-50"></div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>