<?php $__env->startSection('content'); ?>
			<section class="page_slider bottom_mask_subtract">
				<div class="flexslider nav-true">
					<ul class="slides">
						<li class="ds cover-image video-bg text-center">
							<img src="<?php echo e(asset('frontend/images/home_1.jpg')); ?>" class="" alt="img">
							<div class="flex-bg ds z-6 s-overlay">
								<video muted loop id="myVideo">
									<source src="#" data-src="<?php echo e(asset('frontend/images/Comercial_Stock_Models_2018.mp4')); ?>" data-time="26" type="video/mp4">
								</video>
							</div>
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#"class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a beauty queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>

						<li class="cover-image ds s-overlay text-center">
							<img src="<?php echo e(asset('frontend/images/home_2.jpg')); ?>" alt="img">
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#" class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a beauty queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>
						<li class="cover-image ds s-overlay text-center">
							<img src="<?php echo e(asset('frontend/images/home_3.jpg')); ?>" alt="img">
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#" class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a beauty queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>


					</ul>
				</div> <!-- eof flexslider -->
			</section>

			<section class="c-gutter-0 gallery-5 carousel-section ds container-px-0 z-6 transparent-bg overflow-visible s-pt-sm-50">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 text-center">
							<div class="owl-carousel" data-margin="30" data-responsive-lg="5" data-responsive-md="4" data-responsive-sm="3" data-responsive-xs="1" data-nav="" data-loop="true" data-autoplay="true">
								<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(($gallery->pic)); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title"><?php echo e($gallery->fname); ?></div>
											<div class="subtitle"><?php echo e($gallery->lname); ?></div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data"><?php echo e($gallery->height); ?></span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data"><?php echo e($gallery->w); ?></span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data"><?php echo e($gallery->age); ?></span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data"><?php echo e($gallery->hair); ?></span>
											</li>
										</ul>
									</div>
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="about" class="ds hello-section s-pt-70 s-pb-115  s-pb-md-130 s-pb-lg-100 s-pt-lg-175 s-pb-xl-235 overflow-visible s-overlay s-mobile-overlay">
				<div class="container">
					<div class="fw-divider-space hidden-below-xxl pt-250"></div>
					<div class="fw-divider-space hidden-below-lg pt-130"></div>
					<div class="row justify-content-end">
						<div class="col-xs-12 col-lg-6">
							 
							<h4 class="big-title">
								<?php echo e($about->title); ?>

							</h4>
							<div class="fw-divider-space hidden-below-lg mt-45"></div>
							<p class="color-white">
								<?php echo e($about->body); ?>

							</p>
							<div class="fw-divider-space hidden-below-lg mt-65"></div>
							<div class="fw-divider-space hidden-above-lg mt-30"></div>
							<a href="<?php echo e(url('/howtoenter')); ?>" class="btn btn-outline-maincolor">become a queen</a>
							<a href="<?php echo e(route('contact.create')); ?>" class="btn btn-maincolor"> Message Us</a>
						</div>
					
					</div>
					<div class="fw-divider-space hidden-below-lg mt-30"></div>
				</div>
			</section>

			<section id="gallery" class="gallery-section gallery-6 bottom_mask_add overflow-visible ds s-pt-115 s-pb-70 s-pb-md-80 s-pt-md-135 s-pb-xl-155 s-pt-xl-205">
				<div class="container-fluid">
					<div class="row">
						<div class="fw-divider-space hidden-below-xl pt-70"></div>
						<div class="col-lg-12">
							<div class="row justify-content-center">
								<div class="col-md-10 col-xl-8">
									<div class="filters gallery-filters text-lg-right">
										<a href="#" data-filter="*" class="active selected">QUEENS Gallery</a>
									</div>
								</div>
							</div>
							<div class="fw-divider-space hidden-below-lg pt-10"></div>

							<div class="row isotope-wrapper masonry-layout c-gutter-30 c-mb-30 animate" data-animation="fadeInDown" data-filters=".gallery-filters">
								<?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion">
									
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(($gallery->pic)); ?>" alt="img">
											<div class="media-links"></div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title"><?php echo e($gallery->fname); ?></div>
												<div class="subtitle"><?php echo e($gallery->lname); ?></div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data"><?php echo e($gallery->height); ?></span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data"><?php echo e($gallery->w); ?></span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data"><?php echo e($gallery->age); ?></span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data"><?php echo e($gallery->hair); ?></span>
												</li>

											</ul>
										</div>
									</div>
									
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>

							<div class="row">
								<div class="fw-divider-space pt-20 hidden-above-lg"></div>
								<div class="col-12 text-center">
									<div class="btn btn-maincolor"> <a href="#" >ALL BEAUTY QUEENS</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="new-faces" class="faces-section gallery-1 ds top_mask_add overflow-visible item-gallery s-pt-80 s-pb-30 s-pb-md-70 s-pt-md-90 s-pb-xl-120 s-pt-xl-180">
				<div class="container">
					<div class="row">
						<div class="hidden-below-lg col-lg-4 animate" data-animation="fadeInLeft">
							<span class="color-main font-main fs-24 text-uppercase">Impretty</span>
							<h2 class="mt-0 mb-40 text-uppercase">new faces</h2>
							<div class="model-slider-thumbs">
								<ul class="slides">
									<?php $__currentLoopData = $galleries->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(($gallery->pic)); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name"><?php echo e($gallery->fname); ?> <?php echo e($gallery->lname); ?> </a>
											<span class="age"><?php echo e($gallery->age); ?> years old,</span>
											<span class="address"><?php echo e($gallery->location); ?></span>
										</div>
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							
							</div>
							
						</div>
						<div class="col-xs-12 col-lg-8 animate" data-animation="fadeInRight">
							<div class="model-images">
								<div class="model-figure">
									<?php $__currentLoopData = $galleries->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(($gallery->pic)); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title"><?php echo e($gallery->fname); ?></div>
												<div class="subtitle"><?php echo e($gallery->lname); ?></div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data"><?php echo e($gallery->height); ?></span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data"><?php echo e($gallery->w); ?></span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data"><?php echo e($gallery->age); ?></span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data"><?php echo e($gallery->hair); ?></span>
												</li>
											</ul>
										</div>
										
									</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>


			<section class="card-section post overflow-visible">
				<div class="container-fluid">
					<span class="color-main font-main fs-24 text-uppercase text-center"><h2>News & Events</h2></span>
					<div class="row">
						<div class="col-sm-12 text-center">
							<div class="owl-carousel" data-autoplay="true" data-margin="4" data-responsive-lg="" data-responsive-md="3" data-responsive-sm="2" data-responsive-xs="1" data-nav="" data-loop="true">
								<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="item-content">
									<header class="entry-header">
										<a href="<?php echo e(route('events.show',$blog->id)); ?>">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00"><?php echo e($blog->created_at); ?></time>
										</a>
									</header>
									<div class="entry-content">
										<h4 class="entry-title">
										<a href="<?php echo e(route('events.show',$blog->id)); ?>">
											<?php echo e($blog->title); ?>

											</a>
										</h4>
									</div>
									<div class="entry-meta">
										<span class="byline">
											<span class="author vcard d-flex flex-column align-items-center">
												<i class="fa fa-user"></i>
												<a class="url fn n" href="#">By Admin</a>
											</span>
										</span>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="map" class="ds ms page_map top_mask_subtract" data-draggable="false" data-scrollwheel="false">
			</section>

			<section class="ds background-contact s-pt-20 s-pb-60 s-pb-md-90 s-pb-xl-150 c-mb-30">
				<div class="fw-divider-space hidden-below-xl mt-40"></div>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-lg-12">
						<a href="<?php echo e(route('proposal.create')); ?>" class="banner">
								<div class="banner__img cover-image s-overlay">
									<img src="<?php echo e(asset('frontend/images/btn-image_1.jpg')); ?>" alt="img">
								</div>
								<div class="banner__content">
									<h4 class="banner__title">
										Sponsors & Partners
									</h4>
									<div class="banner__text">
										Become a sponsor
									</div>
								</div>
							</a>
						</div>

					</div>
					<div class="row">
						<div class="col-lg-12">
							<div class="cart-collaterals">
								<div class="cross-sells">
									<ul class="products">
										<?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="product type-product">
											<a href="#">
												<img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $sponsor->logo)); ?>" class="" alt="img">
											<h4><?php echo e($sponsor->name); ?></h4>
											</a>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>