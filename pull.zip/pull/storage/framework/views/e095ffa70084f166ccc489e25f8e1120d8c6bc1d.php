<?php $__env->startSection('content'); ?>
<section class="page_title ds bottom_mask_subtract s-pt-30 s-pb-25 pattern-background">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-215"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12">
                <h1 class="small-title">Terms & Conditions</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Contest Terms & Conditions
                    </li>
                </ol>
            </div>

            <div class="fw-divider-space hidden-below-lg mt-215"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

        </div>
    </div>
</section>

<section class="ds c-gutter-60 s-pt-70 s-pb-30 s-pt-md-100 s-pb-md-80 s-pt-xl-150 s-pb-xl-200">
    <div class="container">
        <div class="row">

            <div class="col-lg-8">
                <div class="vertical-item ">
                    <div class="item-content">
                        <h4> TERMS & CONDITIONS </h4>
                        <p>By applying for Impretty Face Of Beauty Pageant, you have agreed to the following terms and conditions. </p>
                        <p> I agree that I meet all requirements of Impretty Face Of Beauty Pageant. As a contestant, I have never been married or given birth to a child and I am between the age of 18 and 26 years. </p>
                        <p> Impretty organization, it's officers, Directors, Staffs and Sponsors are not responsible for any lost or damages at the finals and contestants must have a good background that will not cause any problems or disputes during the pageant. </p>
                        <p> All fees paid for Impretty face of beauty pageant are NOT REFUNDABLE and NOT TRANSFERABLE. Once your entrance fee has been paid, you are able to drop out at any time but you WILL NOT receive a refund. </p>
                        <p> I understand that as a winner of Impretty face of beauty pageant, I cannot compete in another pageant without written consent from Impretty directors. </p>
                        <p> I understand that if I am selected as the winner, I will be required to sign a one-year or length of reign contract/agreement with Impretty Organization and it's directors but if I am unable to represent my title, all gift and cash prizes will be forfeited. This contract/agreement is not negotiable. </p>
                        <p> I agree to participate in all scheduled activities for the pageant dates and cooperate with pageant staffs and assigned chaperones. </p>
                        <p> I will not consume alcohol beverages or publicly smoke while in their crown or sash at anytime during the course of the pageant. Use of illegal drugs is prohibited. </p>
                        <p> I understand that Impretty face of beauty pageant system is not associated with: Miss Nigeria or any other state or national pageant. </p>
                        <h6> Photograph & Videos    </h6>                                                                                                                       
                        <p> ALL finalists must be aware that press and photographers are likely to cover this event. Photos and videos taken during the competition will be used for marketing, this include media use at a national level. </p>
                        <h6> Disqualification / Title Relinquishment      </h6>                                                                                          
                        <p>  If finalists or Winner's are disqualified or relinquished for any reason, any title awarded to her; all prizes must be returned in full. </p>
                        <h6> Travel     </h6>                                                                                                                                              
                        <p> Finalists make their own travel arrangements. Impretty Organization is not responsible for arranging travels or intervening/resolving disputes involving travel of the selected contestants. </p>
                        <h6>Accommodation </h6>                                                                                                                 
                          <p> Finalists and their families must make and finance their own accommodation reservations. </p>
                        <h6>Tickets for the Final  </h6>                                                                                                                              
                        <p>  All finalist supporters are required to buy tickets purchase in advance. There are NO FREE tickets given to any finalists, all tickets are subject to booking fee. </p>
                        <h6>Agreement </h6>                                                                                                                                             
                        <p>  Impretty  face of beauty finalists agrees to abide by the above rules. If a finalists fails to abide by the above rules or brings Impretty organization into disrepute, for which a decision will be made at the Director’s discretion to terminate the finalist’s contract immediately, reclaim the finalists sash and authorise the deletion of all photos containing the Impretty face of beauty queen sash and crown. </p>
                        <p>By submitting the entry form and fee(s) to Impretty Organization, finalist agrees to abide by all policies, rules and regulations set forth by Impretty organization. </p>
                        <p>All finalists must except the judge’s/director’s decision is final, this includes all awards. In the case of a tie the director will make the final decision. This is not open for negotiation. </p>
                        <p>I hearby agree to all of the above.</p>
                        
                            

                    </div>
                </div>
            </div>

            <aside class="col-lg-4 affix-aside">
                <div class="widget widget_categories">

                    <h3 class="widget-title"></h3>

                    <ul>

                    </ul>
                </div>


            </aside>

        </div>
        <div class="fw-divider-space hidden-below-lg mt-30"></div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>