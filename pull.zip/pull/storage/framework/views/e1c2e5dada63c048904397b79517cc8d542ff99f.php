<?php $__env->startSection('content'); ?>

			<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
				<div class="container">
					<div class="row">

						<div class="fw-divider-space hidden-below-lg mt-160"></div>
						<div class="fw-divider-space hidden-above-lg mt-100"></div>

						<div class="col-md-12 text-center">
							<h1>Model Galleries</h1>
							<ol class="breadcrumb">
								<li class="breadcrumb-item">
									<a href="#">Home</a>
								</li>
								<li class="breadcrumb-item">
									<a href="#">Pages</a>
								</li>
								<li class="breadcrumb-item active">
									Gallery
								</li>
							</ol>
						</div>
					</div>
				</div>
			</section>

			<section class="ds s-py-70 s-py-lg-100 s-py-xl-150">
				<div class="container">
					<div class="row">
						<div class="col-lg-12">
							<div class="row isotope-wrapper masonry-layout c-mb-30" data-filters=".gallery-filters">

								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_1.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_2.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_3.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_4.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_5.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_6.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_7.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_8.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion studio">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_9.jpg')); ?>" alt="img">
											<div class="media-links">
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_10.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_11.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_12.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_13.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_14.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 studio session">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_15.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

								<div class="col-xl-3 col-sm-6 fashion studio">
									<div class="vertical-item item-gallery text-center ds">
										<div class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_16.jpg')); ?>" alt="img">
											<div class="media-links">
												<a class="abs-link" title="" href="#"></a>
											</div>
										</div>
									</div>
								</div>

							</div>
							<!-- .isotope-wrapper-->

							<div class="row">
								<div class="fw-divider-space mt-20"></div>
								<div class="col-sm-12 text-center">
									<a href="#" class="btn btn-maincolor">Load More</a>
								</div>
							</div>

						</div>

						<div class="fw-divider-space hidden-below-lg mt-50"></div>
						<div class="fw-divider-space hidden-xs hidden-above-lg mt-30"></div>
					</div>

				</div>
			</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>