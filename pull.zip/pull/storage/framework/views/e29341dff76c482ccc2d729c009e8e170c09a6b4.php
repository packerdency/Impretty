<?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<section class="page_slider bottom_mask_subtract">
				<div class="flexslider nav-true">
					<ul class="slides">
						<li class="ds cover-image video-bg text-center">
							<img src="<?php echo e(asset('frontend/images/home_1.jpg')); ?>" class="" alt="img">
							<div class="flex-bg ds z-6 s-overlay">
								<video muted loop id="myVideo">
									<source src="#" data-src="<?php echo e(asset('frontend/images/Comercial_Stock_Models_2018.mp4')); ?>" data-time="26" type="video/mp4">
								</video>
							</div>
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#"class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-google-plus"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>

						<li class="cover-image ds s-overlay text-center">
							<img src="<?php echo e(asset('frontend/images/home_2.jpg')); ?>" alt="img">
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#" class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-google-plus"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>
						<li class="cover-image ds s-overlay text-center">
							<img src="<?php echo e(asset('frontend/images/home_3.jpg')); ?>" alt="img">
							<div class="soc-buttons">
								<span>follow us:</span>
								<span><a href="#" class="fa fa-facebook"></a></span>
								<span><a href="#" class="fa fa-twitter"></a></span>
								<span><a href="#" class="fa fa-google-plus"></a></span>
								<span><a href="#" class="fa fa-youtube-play"></a></span>
								<span><a href="#" class="fa fa-instagram"></a></span>
							</div>
							<div class="container-fluid">
								<div class="row">
									<div class="col-md-12">
										<div class="intro_layers_wrapper">
											<div class="intro_layers">
												<div class="intro_layer" data-animation="fadeInRight">
													<div class="d-inline-block">
														<h2 class="text-uppercase intro_featured_word">
															top queens
														</h2>
													</div>
												</div>
												<div class="intro_layer mt-30" data-animation="fadeInUp">
													<img src="<?php echo e(asset('frontend/images/home_icon.png')); ?>" alt="img" class="intro_after_featured_word">
													<div class="intro_after_featured_word">
														<a href="#">become a queen</a>
													</div>
												</div>
											</div> <!-- eof .intro_layers -->
										</div> <!-- eof .intro_layers_wrapper -->
									</div> <!-- eof .col-* -->
								</div><!-- eof .row -->
							</div><!-- eof .container-fluid -->
						</li>


					</ul>
				</div> <!-- eof flexslider -->
			</section>

			<section class="c-gutter-0 gallery-5 carousel-section ds container-px-0 z-6 transparent-bg overflow-visible s-pt-sm-50">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 text-center">
							<div class="owl-carousel" data-margin="30" data-responsive-lg="5" data-responsive-md="4" data-responsive-sm="3" data-responsive-xs="1" data-nav="" data-loop="true" data-autoplay="true">
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_17.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">chloe</div>
											<div class="subtitle">nelson</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>
										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_12.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">megan</div>
											<div class="subtitle">duong</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>
										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_18.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">amy</div>
											<div class="subtitle">anderson</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>
										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_20.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">rachel</div>
											<div class="subtitle">anthony</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>
										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_19.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">elena</div>
											<div class="subtitle">murray</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_2.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Afyna</div>
											<div class="subtitle">Cannon</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_3.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Erica</div>
											<div class="subtitle">Peters</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_4.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Evelyn</div>
											<div class="subtitle">Plumb</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_5.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Beatriz</div>
											<div class="subtitle">Lanning</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_6.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Patricia</div>
											<div class="subtitle">Bellomy</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_7.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Lauri</div>
											<div class="subtitle">Pena</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_8.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Maria</div>
											<div class="subtitle">Willis</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media photoswipe-link h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_9.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Marla</div>
											<div class="subtitle">Walker</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>
											<li>
												<span class="title">dress</span>
												<span class="data">2.4</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_10.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Gloria</div>
											<div class="subtitle">Lopez</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_11.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">Faith</div>
											<div class="subtitle">Bayless</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
								<div class="vertical-item item-gallery content-absolute text-center ds">
									<a href="#" class="item-media  h-100 w-100 d-block" data-width="1080" data-height="1520">
										<img src="<?php echo e(asset('frontend/images/gallery/model_1.jpg')); ?>" alt="img">
										<div class="media-links"></div>
									</a>
									<div class="item-content">
										<div class="item-title">
											<div class="title">leslie</div>
											<div class="subtitle">Ball</div>
										</div>
										<ul class="model-data">
											<li>
												<span class="title">height</span>
												<span class="data">183</span>
											</li>
											<li>
												<span class="title">weight</span>
												<span class="data">51</span>
											</li>
											<li>
												<span class="title">age</span>
												<span class="data">21</span>
											</li>
											<li>
												<span class="title">eyes</span>
												<span class="data">blue</span>
											</li>
											<li>
												<span class="title">hair</span>
												<span class="data">brown</span>
											</li>

										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="about" class="ds hello-section s-pt-70 s-pb-115  s-pb-md-130 s-pb-lg-100 s-pt-lg-175 s-pb-xl-235 overflow-visible s-overlay s-mobile-overlay">
				<div class="container">
					<div class="fw-divider-space hidden-below-xxl pt-250"></div>
					<div class="fw-divider-space hidden-below-lg pt-130"></div>
					<div class="row justify-content-end">
						<div class="col-xs-12 col-lg-6">
							<h4 class="big-title">
								hello!
							</h4>
							<div class="fw-divider-space hidden-below-lg mt-45"></div>
							<p class="color-white font-main">
								Impretty, established in 1990, is one of the world's top model agencies, representing some of the fashion industry's most successful faces.
							</p>
							<p>
								A dedicated team of highly experienced professionals have enabled Impretty to sustain its success and dominate the fashion world for over three decades. We are one of the world's top model agencies, representing most successful faces.
							</p>
							<img src="<?php echo e(asset('frontend/images/signature.png')); ?>" alt="signature">
							<div class="fw-divider-space hidden-below-lg mt-65"></div>
							<div class="fw-divider-space hidden-above-lg mt-30"></div>
							<a href="#" class="btn btn-outline-maincolor">become a model</a>
							<a href="#" class="btn btn-maincolor">Schedule Casting</a>
						</div>
					</div>
					<div class="fw-divider-space hidden-below-lg mt-30"></div>
				</div>
			</section>

			<section id="gallery" class="gallery-section gallery-6 bottom_mask_add overflow-visible ds s-pt-115 s-pb-70 s-pb-md-80 s-pt-md-135 s-pb-xl-155 s-pt-xl-205">
				<div class="container-fluid">
					<div class="row">
						<div class="fw-divider-space hidden-below-xl pt-70"></div>
						<div class="col-lg-12">
							<div class="row justify-content-center">
								<div class="col-md-10 col-xl-8">
									<div class="filters gallery-filters text-lg-right">
										<a href="#" data-filter="*" class="active selected">Model Gallery</a>
									</div>
								</div>
							</div>
							<div class="fw-divider-space hidden-below-lg pt-10"></div>

							<div class="row isotope-wrapper masonry-layout c-gutter-30 c-mb-30 animate" data-animation="fadeInDown" data-filters=".gallery-filters">

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_1.jpg')); ?>" alt="img">
											<div class="media-links"></div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">leslie</div>
												<div class="subtitle">Ball</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 studio session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_2.jpg')); ?>" alt="img">
											<div class="media-links"></div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Afyna</div>
												<div class="subtitle">Cannon</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_3.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Erica</div>
												<div class="subtitle">peters</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>
											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 studio">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_4.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Evelyn</div>
												<div class="subtitle">Plumb</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_5.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Beatriz</div>
												<div class="subtitle">Lanning</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 studio session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_6.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Patricia</div>
												<div class="subtitle">Bellomy</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="personal-modal-page.html" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_7.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Lauri</div>
												<div class="subtitle">Pena</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 studio session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_8.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Maria</div>
												<div class="subtitle">Willis</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion studio">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_9.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Marla</div>
												<div class="subtitle">Walker</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_10.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Gloria</div>
												<div class="subtitle">Lopez</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 studio session">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_11.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Faith</div>
												<div class="subtitle">Bayless</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>
											</ul>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-lg-4 col-lgx-3 col-xl-2 fashion">
									<div class="vertical-item item-gallery content-absolute text-center ds">
										<a href="#" class="item-media h-100 w-100 d-block">
											<img src="<?php echo e(asset('frontend/images/gallery/model_12.jpg')); ?>" alt="img">
											<div class="media-links">
												<div class="links-wrap"></div>
											</div>
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">megan</div>
												<div class="subtitle">duong</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>
											</ul>
										</div>
									</div>
								</div>

							</div>

							<div class="row">
								<div class="fw-divider-space pt-20 hidden-above-lg"></div>
								<div class="col-12 text-center">
									<div class="btn btn-maincolor">all models</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="new-faces" class="faces-section gallery-1 ds top_mask_add overflow-visible item-gallery s-pt-80 s-pb-30 s-pb-md-70 s-pt-md-90 s-pb-xl-120 s-pt-xl-180">
				<div class="container">
					<div class="row">
						<div class="hidden-below-lg col-lg-4 animate" data-animation="fadeInLeft">
							<span class="color-main font-main fs-24 text-uppercase">Impretty</span>
							<h2 class="mt-0 mb-40 text-uppercase">new faces</h2>
							<div class="model-slider-thumbs">
								<ul class="slides">
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_5.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Stacy Norris</a>
											<span class="age">22 years old,</span>
											<span class="address">New Yor</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_8.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Cristina Kahler</a>
											<span class="age">20 years old,</span>
											<span class="address">Los Angeles</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_1.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Faith Bayless</a>
											<span class="age">18 years old,</span>
											<span class="address">San Francisco</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_9.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Alice Legere</a>
											<span class="age">21 years old,</span>
											<span class="address">San Diego</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_2.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Patricia Bellomy</a>
											<span class="age">18 years old,</span>
											<span class="address">San Francisco</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_3.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Megan Duong</a>
											<span class="age">21 years old,</span>
											<span class="address">San Diego</span>
										</div>
									</li>
									<li>
										<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_4.jpg')); ?>" alt="img" width="120" height="120">
										<div class="slide-wrap">
											<a href="#" class="name">Afyna Cannon</a>
											<span class="age">21 years old,</span>
											<span class="address">San Diego</span>
										</div>
									</li>
								</ul>
							</div>
						</div>
						<div class="col-xs-12 col-lg-8 animate" data-animation="fadeInRight">
							<div class="model-images">
								<div class="model-figure">
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_5.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Stacy</div>
												<div class="subtitle">Norris</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_8.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Cristina</div>
												<div class="subtitle">Kahler</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_1.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Faith</div>
												<div class="subtitle">Bayless</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_9.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Alice</div>
												<div class="subtitle">Legere</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_2.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Patricia</div>
												<div class="subtitle">Bellomy</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative ">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_3.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">megan</div>
												<div class="subtitle">duong</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
									<div class="border-rad-5 position-relative">
										<a href="#" class="gradientdarken-background z-7-before">
											<img src="<?php echo e(asset('frontend/images/gellery_rectengular/rec_model_4.jpg')); ?>" alt="img" data-caption="" data-large_image_width="555" data-large_image_height="555">
										</a>
										<div class="item-content">
											<div class="item-title">
												<div class="title">Afyna</div>
												<div class="subtitle">Cannon</div>
											</div>
											<ul class="model-data">
												<li>
													<span class="title">height</span>
													<span class="data">183</span>
												</li>
												<li>
													<span class="title">weight</span>
													<span class="data">51</span>
												</li>
												<li>
													<span class="title">age</span>
													<span class="data">21</span>
												</li>
												<li>
													<span class="title">eyes</span>
													<span class="data">blue</span>
												</li>
												<li>
													<span class="title">hair</span>
													<span class="data">brown</span>
												</li>

											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>


			<section class="card-section post overflow-visible">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-12 text-center">
							<div class="owl-carousel" data-autoplay="true" data-margin="4" data-responsive-lg="" data-responsive-md="3" data-responsive-sm="2" data-responsive-xs="1" data-nav="" data-loop="true">
								<div class="item-content">
									<header class="entry-header">
										<a href="#">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">September 1, 2018</time>
										</a>
									</header>
									<div class="entry-content">
										<h4 class="entry-title">
											<a href="#">
												Renaissance Curls That Look Carved Out of Stone pick
											</a>
										</h4>
									</div>
									<div class="entry-meta">
										<span class="byline">
											<span class="author vcard d-flex flex-column align-items-center">
												<i class="fa fa-user"></i>
												<a class="url fn n" href="#">By Admin</a>
											</span>
										</span>
									</div>
								</div>
								<div class="item-content">
									<header class="entry-header">
										<a href="#">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">August 23, 2018</time>
										</a>
									</header>
									<div class="entry-content">
										<h4 class="entry-title">
											<a href="#">
												POP drops heaps of covers, 10, to pick and choose
											</a>
										</h4>
									</div>
									<div class="entry-meta">
										<span class="byline">
											<span class="author vcard d-flex flex-column align-items-center">
												<i class="fa fa-user"></i>
												<a class="url fn n" href="#">By Admin</a>
											</span>
										</span>
									</div>
								</div>
								<div class="item-content">
									<header class="entry-header">
										<a href="#">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">August 18, 2018</time>
										</a>
									</header>
									<div class="entry-content">
										<h4 class="entry-title">
											<a href="#">
												New girls Premier London is ready to launch this tasks
											</a>
										</h4>
									</div>
									<div class="entry-meta">
										<span class="byline">
											<span class="author vcard d-flex flex-column align-items-center">
												<i class="fa fa-user"></i>
												<a class="url fn n" href="#">By Admin</a>
											</span>
										</span>
									</div>
								</div>
								<div class="item-content">
									<header class="entry-header">
										<a href="#">
											<time class="entry-date published updated" datetime="2018-03-18T15:15:12+00:00">August 09, 2018</time>
										</a>
									</header>
									<div class="entry-content">
										<h4 class="entry-title">
											<a href="#">
												WSJ Asks What Makes a 'Perfect Ten' is ready Premier
											</a>
										</h4>
									</div>
									<div class="entry-meta">
										<span class="byline">
											<span class="author vcard d-flex flex-column align-items-center">
												<i class="fa fa-user"></i>
												<a class="url fn n" href="#">By Admin</a>
											</span>
										</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>

			<section id="map" class="ds ms page_map top_mask_subtract" data-draggable="false" data-scrollwheel="false">
			</section>

			<section class="ds background-contact s-pt-20 s-pb-60 s-pb-md-90 s-pb-xl-150 c-mb-30">
				<div class="fw-divider-space hidden-below-xl mt-40"></div>
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-lg-6">
							<a href="#" class="banner">
								<div class="banner__img cover-image s-overlay">
									<img src="<?php echo e(asset('frontend/images/btn-image_1.jpg')); ?>" alt="img">
								</div>
								<div class="banner__content">
									<h4 class="banner__title">
										Become a Model
									</h4>
									<div class="banner__text">
										Know More
									</div>
								</div>
							</a>
						</div>
						<div class="col-xs-12 col-lg-6">
							<a href="#" class="banner">
								<div class="banner__img cover-image s-overlay">
									<img src="<?php echo e(asset('frontend/images/btn-image_2.jpg')); ?>" alt="img">
								</div>
								<div class="banner__content">
									<h4 class="banner__title color-black">
										Model Courses
									</h4>
									<div class="banner__text">
										Know More
									</div>
								</div>
							</a>
						</div>
					</div>
				</div>
				<div class="fw-divider-space hidden-below-xl mt-50"></div>
			</section>

			<?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		</div><!-- eof #box_wrapper -->
	</div><!-- eof #canvas -->


	<script src="<?php echo e(asset('frontend/js/compressed.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>

	<!-- Google Map Script -->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?callback=templateInitGoogleMap&amp;key=AIzaSyC0pr5xCHpaTGv12l73IExOHDJisBP2FK4"></script>

</body>


<!-- index_singlepage12:56:40  -->
</html>