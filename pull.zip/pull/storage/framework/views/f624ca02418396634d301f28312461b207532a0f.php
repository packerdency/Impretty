<?php $__env->startSection('content'); ?>
			<section class="ds s-py-70 s-py-lg-100 s-py-xl-150 s-overlay ds s-mobile-overlay error-404 not-found page_404">
				<div class="container">
					<div class="row justify-content-start">

						<div class="col-12 col-md-7">

							<header class="page-header">
								<h3>404</h3>
								<p>
									Oops, page not found!
								</p>
							</header>
							<!-- .page-header -->

							<div class="page-content">
								<span>You can search what are interested in:</span>
								<div id="search-404" class="widget widget_search p-0">

									<form role="search" method="get" class="search-form" action="#">
										<label for="search-form-404">
											<span class="screen-reader-text">Search for:</span>
										</label>
										<input type="search" id="search-form-404" class="search-field" placeholder="Search keywords" value="" name="search">
										<button type="submit" class="search-submit">
											<span class="screen-reader-text">Search keywords</span>
										</button>
									</form>
								</div>

								<p class="divider_or">or</p>

								<p>
									<a href="<?php echo e(url('/')); ?>" class="btn btn btn-maincolor">back to Homepage</a>
								</p>
							</div>
							<!-- .page-content -->
						</div>

					</div>
				</div>
				<div class="fw-divider-space hidden-below-lg mt-30"></div>
			</section>
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>