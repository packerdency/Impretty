<?php $__env->startSection('content'); ?>
<section class="page_title s-parallax bottom_mask_subtract s-overlay ds title-overlay s-py-md-25">
    <div class="container">
        <div class="row">

            <div class="fw-divider-space hidden-below-lg mt-160"></div>
            <div class="fw-divider-space hidden-above-lg mt-100"></div>

            <div class="col-md-12 text-center">
                <h1>Our Humanitarian Projects</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Pages</a>
                    </li>
                    <li class="breadcrumb-item active">
                        Project
                    </li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="ds team s-pt-70 s-pb-50 s-py-lg-100 s-py-xl-150 c-mb-30">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6">

                <div class="vertical-item box-shadow content-padding text-center border-rad-5">
                    <div class="item-media">
                        <img src="<?php echo e(url('/storage/upload')); ?>/<?php echo e(( $project->image)); ?>" alt="img">
                        <div class="media-links">
                            <a class="abs-link" title="" href="<?php echo e(route('h.show',$project->id)); ?>"></a>
                        </div>
                    </div>
                    <div class="item-content">
                        <h4 class="tile">
                            <a href="<?php echo e(route('h.show',$project->id)); ?>"><?php echo e($project->title); ?></a>
                        </h4>
                    </div>
                </div>
            </div><!-- .col-* -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
    <div class="fw-divider-space hidden-below-lg mt-30"></div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>